import express from 'express';
import type { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// In-memory records store backed by a local JSON file
const DATA_DIR = path.resolve(process.cwd(), 'data');
const RECORDS_FILE = path.join(DATA_DIR, 'financial_records.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface FinancialRecord {
  id: string;
  createdAt: string;
  applicantName?: string;
  monthlyIncome: number;
  monthlyExpenses: number;
  existingEmi: number;
  creditScore: number;
  loanAmount: number;
  loanTenureYears: number;
  estimatedEmi: number;
  eligibilityStatus: 'High' | 'Moderate' | 'Borderline' | 'Ineligible';
  riskCategory: 'Low Risk' | 'Moderate Risk' | 'High Risk' | 'Critical';
  dtiRatio: number;
  employmentType: string;
  notes?: string;
}

function loadRecords(): FinancialRecord[] {
  try {
    if (fs.existsSync(RECORDS_FILE)) {
      const data = fs.readFileSync(RECORDS_FILE, 'utf-8');
      return JSON.parse(data) || [];
    }
  } catch (err) {
    console.error('Error reading records file:', err);
  }
  return [];
}

function saveRecords(records: FinancialRecord[]) {
  try {
    fs.writeFileSync(RECORDS_FILE, JSON.stringify(records, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing records file:', err);
  }
}

// -------------------------------------------------------------
// POST /api/records - Save assessment record & sync to Google Sheets
// -------------------------------------------------------------
app.post('/api/records', async (req: Request, res: Response) => {
  try {
    const {
      applicantName,
      monthlyIncome,
      monthlyExpenses,
      existingEmi,
      creditScore,
      loanAmount,
      loanTenureYears,
      estimatedEmi,
      eligibilityStatus,
      riskCategory,
      dtiRatio,
      employmentType,
      notes,
    } = req.body;

    // Validate essential fields
    if (typeof monthlyIncome !== 'number' || monthlyIncome <= 0) {
      return res.status(400).json({ error: 'Valid monthly income is required.' });
    }

    const newRecord: FinancialRecord = {
      id: `REC-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
      applicantName: applicantName ? String(applicantName).trim() : 'Anonymous Applicant',
      monthlyIncome: Number(monthlyIncome),
      monthlyExpenses: Number(monthlyExpenses || 0),
      existingEmi: Number(existingEmi || 0),
      creditScore: Number(creditScore || 700),
      loanAmount: Number(loanAmount || 0),
      loanTenureYears: Number(loanTenureYears || 5),
      estimatedEmi: Number(estimatedEmi || 0),
      eligibilityStatus: eligibilityStatus || 'Moderate',
      riskCategory: riskCategory || 'Moderate Risk',
      dtiRatio: Number(dtiRatio || 0),
      employmentType: employmentType || 'Salaried',
      notes: notes ? String(notes).slice(0, 500) : '',
    };

    const currentRecords = loadRecords();
    currentRecords.unshift(newRecord);
    // Keep last 100 records
    const trimmed = currentRecords.slice(0, 100);
    saveRecords(trimmed);

    // If Google Sheet Webhook URL is configured, push to Google Sheets
    let googleSheetSynced = false;
    let googleSheetError = null;
    const sheetWebhook = process.env.GOOGLE_SHEET_WEBHOOK_URL;

    if (sheetWebhook && sheetWebhook.startsWith('http')) {
      try {
        const sheetResponse = await fetch(sheetWebhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newRecord),
        });
        if (sheetResponse.ok) {
          googleSheetSynced = true;
        } else {
          googleSheetError = `Google Sheet returned status ${sheetResponse.status}`;
        }
      } catch (err: any) {
        googleSheetError = err?.message || 'Failed to connect to Google Sheet webhook';
      }
    }

    return res.status(201).json({
      success: true,
      record: newRecord,
      googleSheetSynced,
      googleSheetError,
      message: 'Assessment record saved successfully.',
    });
  } catch (error: any) {
    return res.status(500).json({ error: 'Server error saving record: ' + error.message });
  }
});

// -------------------------------------------------------------
// GET /api/records - Retrieve saved assessment records
// -------------------------------------------------------------
app.get('/api/records', (_req: Request, res: Response) => {
  const records = loadRecords();
  return res.json({
    success: true,
    count: records.length,
    records,
    sheetConfigured: Boolean(process.env.GOOGLE_SHEET_WEBHOOK_URL),
  });
});

// -------------------------------------------------------------
// DELETE /api/records/:id - Delete a record
// -------------------------------------------------------------
app.delete('/api/records/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const records = loadRecords();
  const filtered = records.filter((r) => r.id !== id);
  saveRecords(filtered);
  return res.json({ success: true, count: filtered.length });
});

// -------------------------------------------------------------
// POST /api/ai-tips - AI Financial Advisor
// Integrates Gemini 3.8 Flash or Claude via backend proxy
// -------------------------------------------------------------
app.post('/api/ai-tips', async (req: Request, res: Response) => {
  try {
    const {
      monthlyIncome = 50000,
      monthlyExpenses = 20000,
      existingEmi = 10000,
      creditScore = 720,
      loanAmount = 1500000,
      loanTenureYears = 15,
      employmentType = 'Salaried',
      userQuery,
    } = req.body;

    const netDisposable = monthlyIncome - monthlyExpenses - existingEmi;
    const dti = monthlyIncome > 0 ? Math.round(((existingEmi) / monthlyIncome) * 100) : 0;

    const promptContext = `
You are a senior BFSI Financial Risk and Advisory Specialist.
Analyze the following user financial profile and provide structured, objective, and responsible financial guidance:
- Monthly Income: ${monthlyIncome}
- Monthly Living Expenses: ${monthlyExpenses}
- Current Monthly EMIs: ${existingEmi}
- Net Disposable Cashflow: ${netDisposable}
- Current Debt-To-Income (DTI) Ratio: ${dti}%
- Credit Bureau Score: ${creditScore}
- Requested Loan Amount: ${loanAmount}
- Requested Tenure: ${loanTenureYears} Years
- Employment Type: ${employmentType}
${userQuery ? `- Specific User Question: "${userQuery}"` : ''}

CRITICAL RULES:
1. Clearly state that results and tips are informational estimates and NOT official lending or banking decisions.
2. Avoid guaranteed outcomes; suggest verifying with accredited financial advisors or lenders.
3. Provide crisp, actionable recommendations broken down into:
   a) Financial Health Assessment & Affordability
   b) Debt Optimization & EMI Strategy (DTI management)
   c) Credit Score Acceleration Roadmap
   d) Loan Application Readiness & Risk Mitigation
4. Return your advice in clear JSON format with the following keys:
   {
     "summary": "Short 2-3 sentence overview of their financial readiness",
     "healthScore": 75, // 0 to 100 integer estimate
     "affordabilityVerdict": "Healthy" | "Stretched" | "Critical",
     "keyObservations": ["Observation 1", "Observation 2", "Observation 3"],
     "recommendations": [
       { "category": "Debt Strategy", "action": "Action title", "detail": "Specific instructions", "impact": "High" | "Medium" | "Low" },
       { "category": "Credit Score", "action": "Action title", "detail": "Specific instructions", "impact": "High" | "Medium" | "Low" },
       { "category": "Budgeting", "action": "Action title", "detail": "Specific instructions", "impact": "High" | "Medium" | "Low" }
     ],
     "preApplicationChecklist": ["Step 1", "Step 2", "Step 3"],
     "disclaimer": "This analysis is for educational and informational purposes only..."
   }
`;

    // 1. Try Gemini API first (pre-configured via GEMINI_API_KEY)
    if (process.env.GEMINI_API_KEY) {
      try {
        const ai = new GoogleGenAI({
          apiKey: process.env.GEMINI_API_KEY,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptContext,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const rawText = response.text || '';
        const parsed = JSON.parse(rawText);
        return res.json({ success: true, provider: 'gemini-3.8-flash', data: parsed });
      } catch (geminiError: any) {
        console.warn('Gemini call error:', geminiError?.message);
        // Fall through to Anthropic or deterministic fallback
      }
    }

    // 2. Try Anthropic Claude API if configured
    if (process.env.ANTHROPIC_API_KEY) {
      try {
        const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'x-api-key': process.env.ANTHROPIC_API_KEY,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
          },
          body: JSON.stringify({
            model: 'claude-3-5-sonnet-20241022',
            max_tokens: 1500,
            system: 'You are an expert BFSI financial risk analyst. Return strictly valid JSON.',
            messages: [{ role: 'user', content: promptContext }],
          }),
        });

        if (anthropicRes.ok) {
          const anthropicData: any = await anthropicRes.json();
          const textBlock = anthropicData.content?.find((c: any) => c.type === 'text')?.text || '';
          const parsed = JSON.parse(textBlock);
          return res.json({ success: true, provider: 'claude-3-5-sonnet', data: parsed });
        }
      } catch (claudeError: any) {
        console.warn('Claude API error:', claudeError?.message);
      }
    }

    // 3. Deterministic High-Fidelity BFSI Rule-Based Synthesizer (Zero-Failure Fallback)
    const affordabilityVerdict = dti <= 35 && creditScore >= 700 ? 'Healthy' : dti <= 50 ? 'Stretched' : 'Critical';
    const computedScore = Math.min(
      95,
      Math.max(25, Math.round((creditScore / 900) * 45 + (1 - dti / 100) * 35 + (netDisposable > 0 ? 15 : 0)))
    );

    const observations = [
      `Your current debt obligations consume ${dti}% of monthly earnings (benchmark is under 35-40%).`,
      `Credit score of ${creditScore} falls into the ${creditScore >= 750 ? 'Prime' : creditScore >= 680 ? 'Near-Prime' : 'Subprime'} risk category.`,
      `Net free cashflow after expenses and EMIs is approximately ${netDisposable > 0 ? 'positive' : 'negative'} (${netDisposable}).`,
    ];

    const fallbackResponse = {
      summary: `Based on your debt-to-income ratio of ${dti}% and credit rating of ${creditScore}, your financial health profile is ${affordabilityVerdict}. Prioritize buffer preservation before taking on additional long-term liabilities.`,
      healthScore: computedScore,
      affordabilityVerdict,
      keyObservations: observations,
      recommendations: [
        {
          category: 'Debt Strategy',
          action: dti > 40 ? 'Consolidate High-Interest Revolving Balances' : 'Optimize Debt Repayment Trajectory',
          detail:
            dti > 40
              ? 'Your DTI exceeds the 40% underwriting comfort line. Prepay credit cards or high-interest personal loans to lower monthly obligations before lodging your application.'
              : 'Keep total debt servicing comfortably below 35% of gross income to secure prime rate concessions from tier-1 institutional lenders.',
          impact: 'High',
        },
        {
          category: 'Credit Score',
          action: creditScore < 750 ? 'Target Credit Utilization Below 30%' : 'Maintain Pristine Payment Velocity',
          detail:
            creditScore < 750
              ? 'Requesting limit increases or paying down balances mid-cycle can reduce reported credit card utilization, generating a quick 20-40 point boost within 60 days.'
              : 'Set all recurring debt on automated minimum payments to avoid catastrophic accidental 30-day delinquency marks.',
          impact: 'High',
        },
        {
          category: 'Budgeting & Liquidity',
          action: 'Establish 6-Month Emergency Liquidity Reserve',
          detail:
            'Institutional lenders favor applicants who preserve a liquid safety net equal to at least 3-6 months of total expenses and EMIs.',
          impact: 'Medium',
        },
      ],
      preApplicationChecklist: [
        'Collect 6 months of primary bank statements showing uninterrupted salary or business cashflows.',
        'Obtain an updated official CIBIL / Experian / TransUnion bureau report and dispute any inaccurate closed accounts.',
        'Ensure no hard credit inquiries occur within 90 days preceding loan submission.',
        'Calculate exact total processing fees and statutory stamp duty to avoid liquidity shocks.',
      ],
      disclaimer:
        'Estimates for educational and informational purposes only. These metrics do not constitute formal loan sanctions, credit approvals, or legal financial advice. Individual bank underwriting policies vary.',
    };

    return res.json({ success: true, provider: 'bfsi-rules-engine', data: fallbackResponse });
  } catch (error: any) {
    return res.status(500).json({ error: 'Failed to generate financial tips: ' + error.message });
  }
});

// -------------------------------------------------------------
// Vite Middleware / Static Server
// -------------------------------------------------------------
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FinPulse BFSI Server listening on port ${PORT}`);
  });
}

startServer();
