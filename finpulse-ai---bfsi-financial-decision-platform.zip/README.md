# FinPulse AI — AI-Powered BFSI Financial Decision-Making Platform

An institutional-grade **Banking, Financial Services, and Insurance (BFSI)** financial intelligence and decision-making web platform designed to help users evaluate borrowing capacity, diagnose credit risks, model exact loan amortization, and generate personalized financial guidance backed by AI.

---

## 1. Project Introduction & Problem Statement

### The Problem
Evaluating personal creditworthiness, loan affordability, and financial stability often confuses users due to:
* **Opaque Underwriting**: Traditional lenders rarely expose how Debt-To-Income (DTI) and Fixed Obligation to Income Ratio (FOIR) calculations affect borrowing limits.
* **Misunderstood Credit Bureau Factors**: Many borrowers do not know how revolving credit card utilization, tradeline depth, and hard inquiries individually drag down credit scores.
* **Static Amortization Math**: Standard calculators fail to illustrate how small prepayments or interest-rate changes dramatically alter long-term interest burdens.
* **Generic Advice**: Conventional financial portals offer generic advice rather than personalized, risk-adjusted actions based on actual cashflows.

### The Objective
FinPulse AI solves these problems by providing transparent mathematical engines, real-time interactive visualization, and responsible AI-powered advisory to educate users before they submit formal lending applications.

> **Important Regulatory Notice**: All calculations, risk scores, and AI recommendations are analytical estimates intended strictly for educational and informational purposes. They do not constitute formal loan sanctions, credit approvals, or legal financial advice.

---

## 2. Core Modules

1. **Loan Eligibility Checker**
   * Computes allowable FOIR thresholds (45% - 65%) based on gross income brackets.
   * Reverse-calculates estimated maximum eligible loan amounts at prevailing benchmark rates.
   * Real-time Debt-to-Income (DTI) gauge with institutional bank tolerance limits.
   * Multi-factor scoring model across 5 pillars: Income (25 pts), Credit Score (25 pts), DTI/FOIR (25 pts), Employment Stability (15 pts), and Age vs. Maturity (10 pts).
   * Generates actionable improvement suggestions (e.g. adding a co-applicant, reducing high-interest debt).
   * 1-click option to save assessments and synchronize records to Google Sheets.

2. **Credit Score Analyzer**
   * Evaluates 5 industry credit bureau pillars:
     * Payment History (35% weight)
     * Credit Card Utilization Ratio (30% weight)
     * Length of Credit History (15% weight)
     * Credit Mix (10% weight)
     * Recent Hard Inquiries (10% weight)
   * Detailed diagnostic narratives for revolving utilization drag and delinquency marks.
   * 30 / 60 / 90-Day Credit Score Enhancement Roadmap.
   * Interactive "What-If" Debt Paydown Simulator showing utilization recovery.

3. **EMI & Amortization Calculator**
   * Exact mathematical installment formula: $EMI = \frac{P \times R \times (1+R)^N}{(1+R)^N - 1}$.
   * Explicit handling of 0% subvention/zero-interest loans ($EMI = P / N$).
   * Dynamic visual breakdown comparing Principal vs. Interest totals.
   * Complete annual and monthly amortization schedule table with CSV download.
   * Prepayment simulator demonstrating total interest saved and tenure months reduced.

4. **AI Financial Guidance & Advisory**
   * Secure backend proxy connecting to Gemini 3.8 Flash (`@google/genai`) or Anthropic Claude 3.5 Sonnet.
   * No API keys or credentials exposed in frontend bundles.
   * Provides an Executive Readiness Verdict (`Healthy` | `Stretched` | `Critical`), Health Score, Key Risk Observations, Prioritized Recommendations (High/Medium/Low Impact), and a Pre-Application Checklist.
   * High-fidelity BFSI rule synthesizer zero-failure fallback for offline or unkeyed runs.

5. **Records Ledger & Google Sheets Integration**
   * Persistent server-side store (`data/financial_records.json`).
   * Asynchronous webhook forwarding to Google Sheets via Google Apps Script (no GCP credentials exposed).
   * Complete CSV and JSON export capability for auditing and spreadsheets.

---

## 3. System Architecture & Diagrams

### System Architecture Diagram

```
                        +------------------------------------+
                        |             USER AGENT             |
                        |    React 19 SPA + Glassmorphism    |
                        +------------------------------------+
                                          |
                               [Client-Side Validation]
                                          |
             +----------------------------+----------------------------+
             |                            |                            |
    +------------------+         +------------------+         +------------------+
    |   LOAN ENGINE    |         | CREDIT ANALYZER  |         |  EMI CALCULATOR  |
    | FOIR, DTI, Score |         | 5 Pillars & Risk |         | Exact Formula &  |
    | Component Weight |         | Bureau Roadmap   |         | Amortization CSV |
    +------------------+         +------------------+         +------------------+
             |                            |                            |
             +----------------------------+----------------------------+
                                          |
                        +------------------------------------+
                        |          BACKEND PROXY             |
                        |      Express.js API Layer          |
                        +------------------------------------+
                                     /          \
                                    /            \
           +-------------------------------+      +-------------------------------+
           |       AI ADVISORY ENGINE      |      |   DATA STORAGE & INTEGRATION  |
           |  - Gemini 3.8 Flash (@genai)  |      |  - Local JSON Records Store   |
           |  - Anthropic Claude 3.5 Proxy |      |  - Google Sheets Webhook Sync |
           |  - High-Fidelity Rule Fallback|      |  - CSV/JSON Export Stream     |
           +-------------------------------+      +-------------------------------+
```

### Loan Eligibility Decision Flowchart

```
START
  |
  +--> Input: Monthly Income, Expenses, Existing EMI, Tenure, Credit Score, Age, Co-Applicant
  |
  +--> Validate: Required fields, positive values, age (18-75), score (300-900)
  |
  +--> Calculate DTI = (Existing EMI / Monthly Income) * 100
  |
  +--> Determine Allowable FOIR:
  |       - Income < 50k: 45-50%
  |       - Income 50k - 100k: 55%
  |       - Income > 100k: 60-65%
  |       - Co-Applicant: +5% Booster
  |
  +--> Max Allowable New EMI = (Monthly Income * FOIR) - Existing EMI
  |
  +--> Reverse-discount Max Eligible Loan: P = EMI * ((1+R)^N - 1) / (R * (1+R)^N)
  |
  +--> Multi-factor Score: Income(25) + Credit(25) + DTI(25) + Stability(15) + Age(10)
  |
  +--> Categorize Risk:
  |       - High: Score >= 75 & DTI <= 45% (Low Risk)
  |       - Moderate: Score >= 60 & DTI <= 55% (Moderate Risk)
  |       - Borderline: Score >= 45 (High Risk)
  |       - Ineligible: Score < 45 (Critical Underwriting Flag)
  |
  +--> Display Result, Positive Factors & Actionable Improvement Suggestions
  |
END
```

---

## 4. Google Sheets Webhook Integration

FinPulse connects to Google Sheets without requiring high-privilege service account keys in the browser:

1. In your Google Drive, create a new Google Sheet.
2. Go to **Extensions > Apps Script**.
3. Paste the following script:

```javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "Record ID", "Date", "Applicant", "Monthly Income", 
        "Existing EMI", "Credit Score", "Loan Amount", "Tenure (Yrs)", 
        "Estimated EMI", "Eligibility Status", "Risk Category", "DTI %"
      ]);
    }
    var data = JSON.parse(e.postData.contents);
    sheet.appendRow([
      data.id, data.createdAt, data.applicantName, data.monthlyIncome, 
      data.existingEmi, data.creditScore, data.loanAmount, data.loanTenureYears, 
      data.estimatedEmi, data.eligibilityStatus, data.riskCategory, data.dtiRatio
    ]);
    return ContentService.createTextOutput(JSON.stringify({result: "success"}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({error: err.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
```

4. Click **Deploy > New Deployment**.
5. Select **Web app**, set **Execute as: Me**, and **Who has access: Anyone**.
6. Copy the Web App URL and set it in your `.env` file as:
```bash
GOOGLE_SHEET_WEBHOOK_URL="https://script.google.com/macros/s/your-deployment-id/exec"
```
Assessments will now stream directly into your Google Sheet whenever you click "Save Assessment & Sync".

---

## 5. Technology Stack

* **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide React icons, Motion.
* **Design Language**: Dark glassmorphism, responsive grid/flexbox, anti-AI slop typography (`Plus Jakarta Sans`, `JetBrains Mono` tabular-nums), accessible focus rings.
* **Backend**: Express.js server, Node.js, `@google/genai` TypeScript SDK, Anthropic Claude proxy, local JSON persistence.
* **Deployment Targets**: Google Cloud Run, Vercel, Netlify, Docker.

---

## 6. Testing & Quality Assurance Checklist

* [x] **EMI Accuracy**: Verified against financial standard amortizations for normal interest, high rates, and 0% interest loans.
* [x] **Boundary Checks**: Validated income brackets ($0 to $10,000,000), loan tenures (1 to 35 years), credit scores (300 to 900), and ages (18 to 75).
* [x] **Security & Privacy**: No API secrets or Google credentials embedded in client code.
* [x] **Data Minimization**: Collects only macro financial variables; does not ask for or store passwords, OTPs, or bank account numbers.
* [x] **Accessibility**: WCAG AA contrast, keyboard navigability, zero layout overflow, and `prefers-reduced-motion` compliance.

---

## 7. Setup & Run Instructions

```bash
# 1. Install dependencies
npm install

# 2. Configure environment variables (optional for AI/Sheets)
cp .env.example .env

# 3. Start development server (runs Express on port 3000 with Vite middleware)
npm run dev

# 4. Production build
npm run build
npm start
```
