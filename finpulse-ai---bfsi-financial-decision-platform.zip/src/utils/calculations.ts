import {
  CurrencyCode,
  EmiInputs,
  EmiResult,
  AmortizationRow,
  LoanInputs,
  EligibilityResult,
  CreditAnalyzerInputs,
  CreditAnalysisResult,
  PillarScore,
} from '../types/financial';

// Currency Formatter
export function formatCurrency(amount: number, currency: CurrencyCode = 'INR'): string {
  const rounded = Math.round(amount);
  if (currency === 'INR') {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(rounded);
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(rounded);
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('en-US').format(Math.round(num));
}

// -------------------------------------------------------------
// 1. EMI CALCULATOR ENGINE
// Formula: EMI = [P x R x (1+R)^N]/[(1+R)^N-1]
// Handles 0% interest rate explicitly.
// -------------------------------------------------------------
export function calculateEMI(inputs: EmiInputs): EmiResult {
  const { principal, annualInterestRate, tenureYears, prepaymentMonthly = 0 } = inputs;
  const n = Math.max(1, Math.round(tenureYears * 12));
  const P = Math.max(0, principal);
  const r = Math.max(0, annualInterestRate) / 12 / 100;

  let monthlyEmi = 0;

  if (P === 0) {
    return {
      monthlyEmi: 0,
      totalInterest: 0,
      totalRepayment: 0,
      principalAmount: 0,
      interestRatioPercent: 0,
      principalRatioPercent: 100,
      amortizationSchedule: [],
      yearlySummary: [],
    };
  }

  if (r === 0) {
    // Zero-interest financing
    monthlyEmi = P / n;
  } else {
    const rateFactor = Math.pow(1 + r, n);
    monthlyEmi = (P * r * rateFactor) / (rateFactor - 1);
  }

  // Generate monthly amortization schedule
  const schedule: AmortizationRow[] = [];
  let balance = P;
  let accumulatedInterest = 0;

  for (let m = 1; m <= n; m++) {
    const interestForMonth = r === 0 ? 0 : balance * r;
    const principalForMonth = Math.min(balance, monthlyEmi - interestForMonth);
    const endingBalance = Math.max(0, balance - principalForMonth);
    accumulatedInterest += interestForMonth;

    schedule.push({
      month: m,
      year: Math.ceil(m / 12),
      beginningBalance: balance,
      emiPayment: interestForMonth + principalForMonth,
      principalPaid: principalForMonth,
      interestPaid: interestForMonth,
      endingBalance,
      totalInterestToDate: accumulatedInterest,
    });

    balance = endingBalance;
    if (balance <= 0) break;
  }

  const totalRepayment = P + accumulatedInterest;
  const totalInterest = Math.max(0, accumulatedInterest);
  const principalRatioPercent = totalRepayment > 0 ? (P / totalRepayment) * 100 : 100;
  const interestRatioPercent = totalRepayment > 0 ? (totalInterest / totalRepayment) * 100 : 0;

  // Aggregate yearly summary
  const yearlyMap = new Map<number, { principal: number; interest: number; endingBalance: number }>();
  for (const row of schedule) {
    const existing = yearlyMap.get(row.year) || { principal: 0, interest: 0, endingBalance: 0 };
    existing.principal += row.principalPaid;
    existing.interest += row.interestPaid;
    existing.endingBalance = row.endingBalance;
    yearlyMap.set(row.year, existing);
  }

  const yearlySummary = Array.from(yearlyMap.entries()).map(([year, val]) => ({
    year,
    principalPaid: Math.round(val.principal),
    interestPaid: Math.round(val.interest),
    endingBalance: Math.round(val.endingBalance),
  }));

  // Optional: calculate prepayment impact if monthly extra is provided
  let prepaymentSavings = undefined;
  if (prepaymentMonthly > 0 && r > 0) {
    let prepayBalance = P;
    let prepayMonths = 0;
    let prepayInterest = 0;
    const effectiveMonthly = monthlyEmi + prepaymentMonthly;

    while (prepayBalance > 0 && prepayMonths < n) {
      prepayMonths++;
      const interestPart = prepayBalance * r;
      const principalPart = Math.min(prepayBalance, effectiveMonthly - interestPart);
      prepayInterest += interestPart;
      prepayBalance -= principalPart;
      if (prepayBalance <= 0) break;
    }

    prepaymentSavings = {
      interestSaved: Math.max(0, totalInterest - prepayInterest),
      tenureReducedMonths: Math.max(0, n - prepayMonths),
      revisedTenureMonths: prepayMonths,
    };
  }

  return {
    monthlyEmi: Math.round(monthlyEmi),
    totalInterest: Math.round(totalInterest),
    totalRepayment: Math.round(totalRepayment),
    principalAmount: Math.round(P),
    principalRatioPercent: Math.round(principalRatioPercent * 10) / 10,
    interestRatioPercent: Math.round(interestRatioPercent * 10) / 10,
    amortizationSchedule: schedule,
    yearlySummary,
    prepaymentSavings,
  };
}

// -------------------------------------------------------------
// 2. LOAN ELIGIBILITY ENGINE
// Evaluates Income, FOIR, DTI, Credit Score, Stability, Age vs Tenure
// -------------------------------------------------------------
export function calculateLoanEligibility(inputs: LoanInputs): EligibilityResult {
  const {
    monthlyIncome,
    monthlyExpenses,
    existingEmi,
    creditScore,
    desiredLoanAmount,
    loanTenureYears,
    age,
    employmentType,
    employmentDurationYears,
    hasCoApplicant = false,
  } = inputs;

  const positiveFactors: string[] = [];
  const areasToImprove: string[] = [];
  const improvementSuggestions: string[] = [];

  // 1. Debt-to-Income (DTI) and FOIR
  // DTI considers debt obligations against gross monthly income
  const dtiRatio = monthlyIncome > 0 ? (existingEmi / monthlyIncome) * 100 : 100;
  // FOIR considers both existing debt obligations and baseline living expenses
  const foirRatio = monthlyIncome > 0 ? ((existingEmi + monthlyExpenses) / monthlyIncome) * 100 : 100;

  // Maximum allowable FOIR threshold by banking convention:
  // Under ₹50,000/mo: ~45-50%
  // ₹50,000 to ₹100,000/mo: ~55%
  // Above ₹100,000/mo: ~60-65%
  let allowableFoirPercent = 0.5;
  if (monthlyIncome >= 100000) {
    allowableFoirPercent = 0.6;
  } else if (monthlyIncome >= 50000) {
    allowableFoirPercent = 0.55;
  } else {
    allowableFoirPercent = 0.45;
  }

  if (hasCoApplicant) {
    allowableFoirPercent += 0.05; // Co-applicant booster
  }

  // Max allowable EMI for NEW loan:
  const maxTotalEmiAllowance = monthlyIncome * allowableFoirPercent;
  const maxMonthlyEmiCapacity = Math.max(0, maxTotalEmiAllowance - existingEmi);

  // Benchmark interest rate for eligibility estimation (assumed 9.25% p.a.)
  const benchmarkAnnualRate = creditScore >= 750 ? 8.75 : creditScore >= 700 ? 9.25 : 10.5;
  const benchmarkMonthlyRate = benchmarkAnnualRate / 12 / 100;
  const tenureMonths = Math.max(1, loanTenureYears * 12);

  // Reverse calculate maximum eligible loan from maxMonthlyEmiCapacity
  // P = EMI * ((1+R)^N - 1) / (R * (1+R)^N)
  let estimatedEligibleLoanAmount = 0;
  if (maxMonthlyEmiCapacity > 0 && benchmarkMonthlyRate > 0) {
    const rf = Math.pow(1 + benchmarkMonthlyRate, tenureMonths);
    estimatedEligibleLoanAmount = (maxMonthlyEmiCapacity * (rf - 1)) / (benchmarkMonthlyRate * rf);
  }

  // -------------------------
  // Scoring Model (Max 100)
  // -------------------------
  // 1. Income Factor (Max 25 pts)
  let incomeFactorScore = 0;
  if (monthlyIncome >= 150000) incomeFactorScore = 25;
  else if (monthlyIncome >= 100000) incomeFactorScore = 22;
  else if (monthlyIncome >= 60000) incomeFactorScore = 18;
  else if (monthlyIncome >= 35000) incomeFactorScore = 14;
  else if (monthlyIncome >= 20000) incomeFactorScore = 9;
  else incomeFactorScore = 4;

  if (monthlyIncome >= 60000) {
    positiveFactors.push('Strong monthly income bracket enhances borrowing power');
  } else {
    areasToImprove.push('Income level places you in a conservative lending tier');
  }

  // 2. Credit Score Factor (Max 25 pts)
  let creditFactorScore = 0;
  if (creditScore >= 780) {
    creditFactorScore = 25;
    positiveFactors.push(`Excellent credit score (${creditScore}) qualifies for tier-1 preferential interest rates`);
  } else if (creditScore >= 730) {
    creditFactorScore = 21;
    positiveFactors.push(`Good credit score (${creditScore}) meets standard institutional lending criteria`);
  } else if (creditScore >= 670) {
    creditFactorScore = 15;
    areasToImprove.push(`Credit score (${creditScore}) is acceptable but may incur higher rate margins`);
    improvementSuggestions.push('Improve credit score to 750+ by lowering card utilization below 30% before applying');
  } else if (creditScore >= 600) {
    creditFactorScore = 8;
    areasToImprove.push(`Credit score (${creditScore}) indicates elevated credit risk to automated underwriters`);
    improvementSuggestions.push('Clear any lingering past dues and delay new loan applications for 60-90 days');
  } else {
    creditFactorScore = 2;
    areasToImprove.push(`Low credit score (${creditScore}) requires credit rehabilitation or secured collateral`);
    improvementSuggestions.push('Consider credit repair steps or adding a creditworthy co-applicant');
  }

  // 3. Debt Obligation / DTI Factor (Max 25 pts)
  let debtObligationScore = 0;
  if (dtiRatio <= 20) {
    debtObligationScore = 25;
    positiveFactors.push(`Low debt obligations (DTI ${Math.round(dtiRatio)}%) leave generous room for new repayments`);
  } else if (dtiRatio <= 35) {
    debtObligationScore = 20;
    positiveFactors.push(`Healthy DTI ratio (${Math.round(dtiRatio)}%) within standard regulatory limits`);
  } else if (dtiRatio <= 50) {
    debtObligationScore = 12;
    areasToImprove.push(`Existing debt is moderately stretched (${Math.round(dtiRatio)}% of gross earnings)`);
    improvementSuggestions.push('Prepay small personal debts or credit cards to free up monthly cashflow');
  } else {
    debtObligationScore = 4;
    areasToImprove.push(`Existing EMIs consume ${Math.round(dtiRatio)}% of income, causing debt-servicing strain`);
    improvementSuggestions.push('Close existing liabilities before undertaking additional borrowing');
  }

  // 4. Employment Stability Factor (Max 15 pts)
  let employmentScore = 0;
  if (employmentType === 'Salaried' || employmentType === 'Self-Employed Professional') {
    employmentScore += 8;
  } else {
    employmentScore += 5;
  }

  if (employmentDurationYears >= 3) {
    employmentScore += 7;
    positiveFactors.push(`Solid employment stability (${employmentDurationYears} years in current role)`);
  } else if (employmentDurationYears >= 1) {
    employmentScore += 5;
  } else {
    employmentScore += 2;
    areasToImprove.push('Short duration at current employer (<1 yr) may flag stability checks');
    improvementSuggestions.push('Maintain continuous tenure for at least 12 months with current organization');
  }

  // 5. Age vs Tenure Alignment (Max 10 pts)
  let ageTenureScore = 0;
  const ageAtMaturity = age + loanTenureYears;
  const retirementAge = 60;

  if (age >= 23 && age <= 48 && ageAtMaturity <= retirementAge) {
    ageTenureScore = 10;
    positiveFactors.push(`Loan completes before typical retirement age (${ageAtMaturity} yrs at maturity)`);
  } else if (ageAtMaturity <= 65) {
    ageTenureScore = 7;
  } else if (ageAtMaturity <= 70) {
    ageTenureScore = 4;
    areasToImprove.push(`Tenure extends past age 65 (${ageAtMaturity} yrs), requiring pension or passive income proof`);
    improvementSuggestions.push('Shorten loan tenure so maturity aligns with pre-retirement years');
  } else {
    ageTenureScore = 1;
    areasToImprove.push('Loan maturity crosses 70 years of age');
    improvementSuggestions.push('Reduce tenure or add a younger working co-borrower');
  }

  // Bonus for co-applicant
  if (hasCoApplicant) {
    positiveFactors.push('Co-applicant income/credit added, strengthening risk profile');
    improvementSuggestions.push('Ensure co-applicant KYC and bank statement documentation is readily aligned');
  }

  // Total Score Calculation
  const totalScore = Math.min(
    100,
    incomeFactorScore + creditFactorScore + debtObligationScore + employmentScore + ageTenureScore
  );

  // Status mapping
  let status: 'High' | 'Moderate' | 'Borderline' | 'Ineligible';
  let riskCategory: 'Low Risk' | 'Moderate Risk' | 'High Risk' | 'Critical';

  if (totalScore >= 75 && dtiRatio <= 45 && creditScore >= 680) {
    status = 'High';
    riskCategory = 'Low Risk';
  } else if (totalScore >= 60 && dtiRatio <= 55) {
    status = 'Moderate';
    riskCategory = 'Moderate Risk';
  } else if (totalScore >= 45) {
    status = 'Borderline';
    riskCategory = 'High Risk';
  } else {
    status = 'Ineligible';
    riskCategory = 'Critical';
  }

  // If requested amount exceeds estimated eligibility, add advisory
  if (desiredLoanAmount > estimatedEligibleLoanAmount && estimatedEligibleLoanAmount > 0) {
    areasToImprove.push(
      `Desired loan amount exceeds estimated maximum capacity by ~${Math.round(
        ((desiredLoanAmount - estimatedEligibleLoanAmount) / estimatedEligibleLoanAmount) * 100
      )}%`
    );
    improvementSuggestions.push(
      'Increase down-payment / tenure or opt for a joint application to cover the remaining balance'
    );
  }

  return {
    score: totalScore,
    status,
    riskCategory,
    estimatedEligibleLoanAmount: Math.round(estimatedEligibleLoanAmount),
    maxMonthlyEmiCapacity: Math.round(maxMonthlyEmiCapacity),
    dtiRatio: Math.round(dtiRatio * 10) / 10,
    foirRatio: Math.round(foirRatio * 10) / 10,
    positiveFactors,
    areasToImprove,
    improvementSuggestions,
    breakdown: {
      incomeFactorScore,
      creditFactorScore,
      debtObligationScore,
      employmentScore,
      ageTenureScore,
    },
  };
}

// -------------------------------------------------------------
// 3. CREDIT SCORE ANALYZER ENGINE
// Evaluates 5 industry credit pillars, risk grade, and roadmap
// -------------------------------------------------------------
export function analyzeCreditScore(inputs: CreditAnalyzerInputs): CreditAnalysisResult {
  const {
    creditScore,
    paymentHistoryPercent,
    creditUtilizationPercent,
    activeLoansCount,
    creditCardsCount,
    creditHistoryYears,
    hardInquiriesLast6Months,
    latePaymentsCount,
  } = inputs;

  let category: 'Excellent' | 'Good' | 'Fair' | 'Needs Improvement' | 'High Risk';
  let riskLevel: 'Low Risk' | 'Moderate Risk' | 'Elevated Risk' | 'High Risk' | 'Severe Risk';
  let approvalProbability: 'Very High' | 'High' | 'Moderate' | 'Low' | 'Unlikely';

  if (creditScore >= 780) {
    category = 'Excellent';
    riskLevel = 'Low Risk';
    approvalProbability = 'Very High';
  } else if (creditScore >= 720) {
    category = 'Good';
    riskLevel = 'Moderate Risk';
    approvalProbability = 'High';
  } else if (creditScore >= 660) {
    category = 'Fair';
    riskLevel = 'Elevated Risk';
    approvalProbability = 'Moderate';
  } else if (creditScore >= 580) {
    category = 'Needs Improvement';
    riskLevel = 'High Risk';
    approvalProbability = 'Low';
  } else {
    category = 'High Risk';
    riskLevel = 'Severe Risk';
    approvalProbability = 'Unlikely';
  }

  // 1. Payment History Pillar (35% weight)
  let paymentStatus: 'Excellent' | 'Good' | 'Fair' | 'Poor' = 'Good';
  let paymentScore = 80;
  if (paymentHistoryPercent >= 99 && latePaymentsCount === 0) {
    paymentStatus = 'Excellent';
    paymentScore = 100;
  } else if (paymentHistoryPercent >= 95 && latePaymentsCount <= 1) {
    paymentStatus = 'Good';
    paymentScore = 80;
  } else if (paymentHistoryPercent >= 88) {
    paymentStatus = 'Fair';
    paymentScore = 60;
  } else {
    paymentStatus = 'Poor';
    paymentScore = 35;
  }

  // 2. Credit Utilization Pillar (30% weight)
  let utilStatus: 'Excellent' | 'Good' | 'Fair' | 'Poor' = 'Good';
  let utilScore = 75;
  if (creditUtilizationPercent <= 10) {
    utilStatus = 'Excellent';
    utilScore = 100;
  } else if (creditUtilizationPercent <= 30) {
    utilStatus = 'Good';
    utilScore = 85;
  } else if (creditUtilizationPercent <= 50) {
    utilStatus = 'Fair';
    utilScore = 60;
  } else {
    utilStatus = 'Poor';
    utilScore = 30;
  }

  // 3. Length of Credit History (15% weight)
  let ageStatus: 'Excellent' | 'Good' | 'Fair' | 'Poor' = 'Good';
  let ageScore = 70;
  if (creditHistoryYears >= 7) {
    ageStatus = 'Excellent';
    ageScore = 100;
  } else if (creditHistoryYears >= 4) {
    ageStatus = 'Good';
    ageScore = 80;
  } else if (creditHistoryYears >= 2) {
    ageStatus = 'Fair';
    ageScore = 60;
  } else {
    ageStatus = 'Poor';
    ageScore = 40;
  }

  // 4. Credit Mix (10% weight)
  let mixStatus: 'Excellent' | 'Good' | 'Fair' | 'Poor' = 'Good';
  let mixScore = 75;
  const hasMultipleTypes = activeLoansCount > 0 && creditCardsCount > 0;
  if (hasMultipleTypes && activeLoansCount + creditCardsCount <= 6) {
    mixStatus = 'Excellent';
    mixScore = 100;
  } else if (activeLoansCount + creditCardsCount > 0) {
    mixStatus = 'Good';
    mixScore = 80;
  } else {
    mixStatus = 'Fair';
    mixScore = 50;
  }

  // 5. New Credit Inquiries (10% weight)
  let inqStatus: 'Excellent' | 'Good' | 'Fair' | 'Poor' = 'Good';
  let inqScore = 85;
  if (hardInquiriesLast6Months === 0) {
    inqStatus = 'Excellent';
    inqScore = 100;
  } else if (hardInquiriesLast6Months <= 2) {
    inqStatus = 'Good';
    inqScore = 80;
  } else if (hardInquiriesLast6Months <= 4) {
    inqStatus = 'Fair';
    inqScore = 55;
  } else {
    inqStatus = 'Poor';
    inqScore = 30;
  }

  const pillars: PillarScore[] = [
    {
      name: 'Payment History',
      weightPercent: 35,
      status: paymentStatus,
      scoreValue: paymentScore,
      comment:
        latePaymentsCount === 0
          ? `${paymentHistoryPercent}% on-time payment record without delinquencies.`
          : `${latePaymentsCount} late payment record(s) flagged in history.`,
      benchmark: 'Target 100% on-time payments with 0 delinquencies',
    },
    {
      name: 'Credit Utilization Ratio',
      weightPercent: 30,
      status: utilStatus,
      scoreValue: utilScore,
      comment: `Current utilization is ${creditUtilizationPercent}% across active revolving limits.`,
      benchmark: 'Keep total credit utilization strictly under 30% (ideally < 10%)',
    },
    {
      name: 'Credit History Age',
      weightPercent: 15,
      status: ageStatus,
      scoreValue: ageScore,
      comment: `Average depth of credit profile is ${creditHistoryYears} years.`,
      benchmark: 'Maintain oldest tradelines to build 5+ years of account maturity',
    },
    {
      name: 'Credit Mix Diversity',
      weightPercent: 10,
      status: mixStatus,
      scoreValue: mixScore,
      comment: `${activeLoansCount} active installment loan(s) & ${creditCardsCount} revolving card(s).`,
      benchmark: 'Healthy balance of secured and unsecured credit products',
    },
    {
      name: 'Recent Inquiries (6 Mo)',
      weightPercent: 10,
      status: inqStatus,
      scoreValue: inqScore,
      comment: `${hardInquiriesLast6Months} hard inquiries logged within the trailing 6 months.`,
      benchmark: 'Fewer than 2 hard inquiries within any 6-month period',
    },
  ];

  // Specific Deep Insights
  const utilizationInsight =
    creditUtilizationPercent > 30
      ? `Your credit card utilization of ${creditUtilizationPercent}% is above the optimal 30% ceiling. Credit scoring algorithms penalize high balances as potential liquidity distress. Paying down balances to below 20% can generate an immediate 15 to 35 point recovery within one reporting cycle.`
      : `Outstanding utilization of ${creditUtilizationPercent}% demonstrates disciplined liquidity management and bolsters your bureau standing.`;

  const paymentHistoryInsight =
    latePaymentsCount > 0
      ? `${latePaymentsCount} historical delinquency instances are lowering your payment track record. Recent payment momentum heavily outweighs older marks—maintaining 6 consecutive months of flawless on-time settlement will steadily restore prime status.`
      : 'Pristine payment history. Ensuring all standing instructions and auto-debits remain funded is the single highest leverage factor in maintaining your rating.';

  const debtManagementInsight =
    activeLoansCount > 3 || hardInquiriesLast6Months > 3
      ? 'Recent credit velocity shows elevated debt-seeking activity. Pause lodging fresh loan applications for at least 90 days to allow inquiry fatigue to reset.'
      : 'Your credit mix and inquiry volume reflect stable, measured borrowing practices.';

  // Actionable Roadmap
  const thirtyDays = [
    'Pay down highest utilization credit cards before the billing statement generation date.',
    'Enroll all revolving cards and loan obligations in automated minimum payments to eliminate risk of missed dates.',
    'Check bureau report for reporting mismatches, phantom accounts, or outdated closed loans.',
  ];

  const sixtyDays = [
    'Request a credit limit enhancement on your oldest card (without hard pull) to automatically dilute your utilization ratio.',
    'Avoid opening retail store cards or applying for short-term instant consumer loans.',
    'Keep your oldest credit card active with a nominal recurring subscription to preserve age of accounts.',
  ];

  const ninetyDays = [
    'Re-pull a refreshed bureau score to observe the utilization recovery impact.',
    'Consolidate scattered high-interest revolving balances into a single lower-rate structured tenure if needed.',
    'Prepare sanitized 6-month primary bank statements showing disciplined credit servicing for upcoming formal loan applications.',
  ];

  return {
    score: creditScore,
    category,
    riskLevel,
    approvalProbability,
    pillars,
    insights: {
      utilizationInsight,
      paymentHistoryInsight,
      debtManagementInsight,
    },
    actionableRoadmap: {
      thirtyDays,
      sixtyDays,
      ninetyDays,
    },
  };
}
