import React, { useState, useEffect } from 'react';
import { CurrencyCode, LoanInputs } from './types/financial';
import { Navbar } from './components/Navbar';
import { DashboardOverview } from './components/DashboardOverview';
import { LoanEligibilityModule } from './components/LoanEligibilityModule';
import { CreditScoreModule } from './components/CreditScoreModule';
import { EmiCalculatorModule } from './components/EmiCalculatorModule';
import { AiFinancialTipsModule } from './components/AiFinancialTipsModule';
import { RecordsDrawer } from './components/RecordsDrawer';
import { ArchitectureDocsModal } from './components/ArchitectureDocsModal';
import { Footer } from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [currency, setCurrency] = useState<CurrencyCode>('INR');
  const [recordsCount, setRecordsCount] = useState<number>(0);
  const [isRecordsOpen, setIsRecordsOpen] = useState<boolean>(false);
  const [isDocsOpen, setIsDocsOpen] = useState<boolean>(false);

  // Shared applicant inputs across modules
  const [sharedInputs, setSharedInputs] = useState<LoanInputs>({
    monthlyIncome: 85000,
    monthlyExpenses: 28000,
    existingEmi: 15000,
    creditScore: 740,
    desiredLoanAmount: 3500000,
    loanTenureYears: 15,
    age: 32,
    employmentType: 'Salaried',
    employmentDurationYears: 4,
    existingLoansCount: 1,
    hasCoApplicant: false,
  });

  // Fetch initial records count
  const refreshRecordsCount = async () => {
    try {
      const res = await fetch('/api/records');
      if (res.ok) {
        const data = await res.json();
        setRecordsCount(data.count || 0);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    refreshRecordsCount();
  }, []);

  const handleConsultAI = () => {
    setActiveTab('ai-tips');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleScoreUpdated = (newScore: number) => {
    setSharedInputs((prev) => ({ ...prev, creditScore: newScore }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        currency={currency}
        setCurrency={setCurrency}
        onOpenRecords={() => setIsRecordsOpen(true)}
        onOpenDocs={() => setIsDocsOpen(true)}
        recordsCount={recordsCount}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {activeTab === 'dashboard' && (
          <DashboardOverview
            onNavigate={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            currency={currency}
            sharedInputs={sharedInputs}
            setSharedInputs={setSharedInputs}
            recordsCount={recordsCount}
          />
        )}

        {activeTab === 'loan' && (
          <LoanEligibilityModule
            currency={currency}
            sharedInputs={sharedInputs}
            setSharedInputs={setSharedInputs}
            onConsultAI={handleConsultAI}
            onRecordSaved={refreshRecordsCount}
          />
        )}

        {activeTab === 'credit' && (
          <CreditScoreModule
            onConsultAI={handleConsultAI}
            sharedCreditScore={sharedInputs.creditScore}
            onScoreUpdated={handleScoreUpdated}
          />
        )}

        {activeTab === 'emi' && (
          <EmiCalculatorModule
            currency={currency}
            onConsultAI={handleConsultAI}
            sharedLoanAmount={sharedInputs.desiredLoanAmount}
          />
        )}

        {activeTab === 'ai-tips' && (
          <AiFinancialTipsModule
            currency={currency}
            sharedInputs={sharedInputs}
          />
        )}
      </main>

      {/* Records Ledger Drawer */}
      <RecordsDrawer
        isOpen={isRecordsOpen}
        onClose={() => setIsRecordsOpen(false)}
        currency={currency}
      />

      {/* Architecture & Documentation Modal */}
      <ArchitectureDocsModal
        isOpen={isDocsOpen}
        onClose={() => setIsDocsOpen(false)}
      />

      {/* Footer */}
      <Footer
        onNavigate={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenDocs={() => setIsDocsOpen(true)}
      />
    </div>
  );
}
