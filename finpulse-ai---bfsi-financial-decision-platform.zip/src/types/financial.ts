export type CurrencyCode = 'INR' | 'USD';

export type EmploymentType =
  | 'Salaried'
  | 'Self-Employed Professional'
  | 'Self-Employed Business'
  | 'Freelancer / Gig Economy';

export interface LoanInputs {
  monthlyIncome: number;
  monthlyExpenses: number;
  existingEmi: number;
  creditScore: number;
  desiredLoanAmount: number;
  loanTenureYears: number;
  age: number;
  employmentType: EmploymentType;
  employmentDurationYears: number;
  existingLoansCount: number;
  hasCoApplicant?: boolean;
}

export interface EligibilityResult {
  score: number; // 0 - 100
  status: 'High' | 'Moderate' | 'Borderline' | 'Ineligible';
  riskCategory: 'Low Risk' | 'Moderate Risk' | 'High Risk' | 'Critical';
  estimatedEligibleLoanAmount: number;
  maxMonthlyEmiCapacity: number;
  dtiRatio: number; // Percentage
  foirRatio: number; // Fixed Obligation to Income Ratio %
  positiveFactors: string[];
  areasToImprove: string[];
  improvementSuggestions: string[];
  breakdown: {
    incomeFactorScore: number;
    creditFactorScore: number;
    debtObligationScore: number;
    employmentScore: number;
    ageTenureScore: number;
  };
}

export interface CreditAnalyzerInputs {
  creditScore: number; // 300 to 900
  paymentHistoryPercent: number; // 0 to 100
  creditUtilizationPercent: number; // 0 to 100
  activeLoansCount: number;
  creditCardsCount: number;
  creditHistoryYears: number;
  hardInquiriesLast6Months: number;
  latePaymentsCount: number;
}

export interface PillarScore {
  name: string;
  weightPercent: number;
  status: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  scoreValue: number;
  comment: string;
  benchmark: string;
}

export interface CreditAnalysisResult {
  score: number;
  category: 'Excellent' | 'Good' | 'Fair' | 'Needs Improvement' | 'High Risk';
  riskLevel: 'Low Risk' | 'Moderate Risk' | 'Elevated Risk' | 'High Risk' | 'Severe Risk';
  approvalProbability: 'Very High' | 'High' | 'Moderate' | 'Low' | 'Unlikely';
  pillars: PillarScore[];
  insights: {
    utilizationInsight: string;
    paymentHistoryInsight: string;
    debtManagementInsight: string;
  };
  actionableRoadmap: {
    thirtyDays: string[];
    sixtyDays: string[];
    ninetyDays: string[];
  };
}

export interface EmiInputs {
  principal: number;
  annualInterestRate: number;
  tenureYears: number;
  prepaymentMonthly?: number;
}

export interface AmortizationRow {
  month: number;
  year: number;
  beginningBalance: number;
  emiPayment: number;
  principalPaid: number;
  interestPaid: number;
  endingBalance: number;
  totalInterestToDate: number;
}

export interface EmiResult {
  monthlyEmi: number;
  totalInterest: number;
  totalRepayment: number;
  principalAmount: number;
  interestRatioPercent: number;
  principalRatioPercent: number;
  amortizationSchedule: AmortizationRow[];
  yearlySummary: {
    year: number;
    principalPaid: number;
    interestPaid: number;
    endingBalance: number;
  }[];
  prepaymentSavings?: {
    interestSaved: number;
    tenureReducedMonths: number;
    revisedTenureMonths: number;
  };
}

export interface SavedAssessmentRecord {
  id: string;
  createdAt: string;
  applicantName?: string;
  monthlyIncome: number;
  monthlyExpenses: number;
  existingEmi: number;
  creditScore: number;
  loanAmount: number;
  loanTenureYears: number;
  estimatedEmi: number;
  eligibilityStatus: 'High' | 'Moderate' | 'Borderline' | 'Ineligible';
  riskCategory: 'Low Risk' | 'Moderate Risk' | 'High Risk' | 'Critical';
  dtiRatio: number;
  employmentType: string;
  notes?: string;
}

export interface AITipsResponse {
  summary: string;
  healthScore: number;
  affordabilityVerdict: 'Healthy' | 'Stretched' | 'Critical';
  keyObservations: string[];
  recommendations: {
    category: string;
    action: string;
    detail: string;
    impact: 'High' | 'Medium' | 'Low';
  }[];
  preApplicationChecklist: string[];
  disclaimer: string;
}
