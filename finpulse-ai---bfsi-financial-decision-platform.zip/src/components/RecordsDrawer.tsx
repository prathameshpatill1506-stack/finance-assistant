import React, { useState, useEffect } from 'react';
import { CurrencyCode, SavedAssessmentRecord } from '../types/financial';
import { formatCurrency } from '../utils/calculations';
import {
  FileSpreadsheet,
  X,
  Download,
  Trash2,
  CheckCircle,
  ExternalLink,
  Code,
  Copy,
  RefreshCw,
  AlertCircle,
} from 'lucide-react';

interface RecordsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currency: CurrencyCode;
}

export const RecordsDrawer: React.FC<RecordsDrawerProps> = ({ isOpen, onClose, currency }) => {
  const [records, setRecords] = useState<SavedAssessmentRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [sheetConfigured, setSheetConfigured] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [showScriptModal, setShowScriptModal] = useState(false);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/records');
      if (res.ok) {
        const data = await res.json();
        setRecords(data.records || []);
        setSheetConfigured(Boolean(data.sheetConfigured));
      }
    } catch (err) {
      console.error('Failed to load records:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchRecords();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/records/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setRecords((prev) => prev.filter((r) => r.id !== id));
      }
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  const exportAllCSV = () => {
    if (!records.length) return;
    const headers = [
      'Record ID',
      'Created At',
      'Applicant',
      'Monthly Income',
      'Monthly Expenses',
      'Existing EMI',
      'Credit Score',
      'Desired Loan',
      'Tenure (Yrs)',
      'Estimated EMI',
      'Eligibility Status',
      'Risk Category',
      'DTI %',
      'Employment Type',
    ];

    const rows = records.map((r) => [
      r.id,
      r.createdAt,
      `"${r.applicantName || ''}"`,
      r.monthlyIncome,
      r.monthlyExpenses,
      r.existingEmi,
      r.creditScore,
      r.loanAmount,
      r.loanTenureYears,
      r.estimatedEmi,
      r.eligibilityStatus,
      r.riskCategory,
      r.dtiRatio,
      `"${r.employmentType}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `FinPulse_Records_Ledger_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const sampleAppsScript = `// Google Apps Script for FinPulse Record Streaming
// 1. Create a Google Sheet -> Extensions -> Apps Script
// 2. Paste this code -> Deploy -> New Deployment -> Web App (Access: Anyone)
// 3. Set the resulting URL as GOOGLE_SHEET_WEBHOOK_URL in .env

function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "Record ID", "Date", "Applicant", "Monthly Income", 
        "Existing EMI", "Credit Score", "Loan Amount", "Tenure (Yrs)", 
        "Estimated EMI", "Eligibility Status", "Risk Category", "DTI %"
      ]);
    }
    var data = JSON.parse(e.postData.contents);
    sheet.appendRow([
      data.id, data.createdAt, data.applicantName, data.monthlyIncome, 
      data.existingEmi, data.creditScore, data.loanAmount, data.loanTenureYears, 
      data.estimatedEmi, data.eligibilityStatus, data.riskCategory, data.dtiRatio
    ]);
    return ContentService.createTextOutput(JSON.stringify({result: "success"}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({error: err.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`;

  const copyScript = () => {
    navigator.clipboard.writeText(sampleAppsScript);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/80 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-2xl bg-slate-950 border-l border-slate-800 h-full flex flex-col shadow-2xl">
        {/* Drawer Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">Assessment Records & Google Sheets Sync</h2>
              <p className="text-xs text-slate-400">Secure backend storage ledger for completed financial analyses</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Integration Status Bar */}
        <div className="px-5 py-3 bg-slate-900/60 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${sheetConfigured ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}
            />
            <span className="text-slate-300">
              Google Sheet Webhook:{' '}
              <strong className={sheetConfigured ? 'text-emerald-400' : 'text-amber-400'}>
                {sheetConfigured ? 'Connected & Active' : 'Local Storage Mode'}
              </strong>
            </span>
          </div>

          <button
            onClick={() => setShowScriptModal(!showScriptModal)}
            className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium cursor-pointer"
          >
            <Code className="w-3.5 h-3.5" />
            <span>Setup Google Sheets Webhook</span>
          </button>
        </div>

        {/* Webhook instructions dropdown */}
        {showScriptModal && (
          <div className="p-4 bg-slate-900 border-b border-slate-800 text-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200">Google Sheets Webhook Script (No Auth Keys Exposed)</span>
              <button
                onClick={copyScript}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 flex items-center gap-1 border border-slate-700 cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>{copiedScript ? 'Copied!' : 'Copy Apps Script'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-950 rounded-lg text-[11px] font-mono text-slate-400 overflow-x-auto max-h-40 border border-slate-800">
              {sampleAppsScript}
            </pre>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Once deployed as a Web App, add the URL to your <code>GOOGLE_SHEET_WEBHOOK_URL</code> environment
              variable. All records saved via the frontend will automatically stream into your spreadsheet.
            </p>
          </div>
        )}

        {/* Content / Records List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">
              Total Saved Assessments: <strong className="text-slate-100 font-mono">{records.length}</strong>
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={fetchRecords}
                className="p-1 text-slate-400 hover:text-slate-200 cursor-pointer"
                title="Refresh"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              </button>
              {records.length > 0 && (
                <button
                  onClick={exportAllCSV}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium flex items-center gap-1 border border-slate-700 cursor-pointer"
                >
                  <Download className="w-3 h-3 text-emerald-400" />
                  <span>Export CSV</span>
                </button>
              )}
            </div>
          </div>

          {records.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <FileSpreadsheet className="w-10 h-10 text-slate-600 mx-auto" />
              <div className="space-y-1">
                <p className="text-sm font-semibold text-slate-300">No Assessment Records Yet</p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Evaluate your loan eligibility or EMI in the platform, then click "Save Assessment & Sync" to persist
                  your results.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {records.map((rec) => (
                <div
                  key={rec.id}
                  className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-colors space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-cyan-400 font-semibold">{rec.id}</span>
                      <span className="text-slate-500">·</span>
                      <span className="text-slate-300 font-medium">{rec.applicantName}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                          rec.eligibilityStatus === 'High'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : rec.eligibilityStatus === 'Moderate'
                            ? 'bg-cyan-500/20 text-cyan-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        {rec.eligibilityStatus}
                      </span>
                      <button
                        onClick={() => handleDelete(rec.id)}
                        className="text-slate-500 hover:text-rose-400 transition-colors cursor-pointer p-1"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[11px] text-slate-400">
                    <div>
                      Income:{' '}
                      <strong className="text-slate-200">{formatCurrency(rec.monthlyIncome, currency)}</strong>
                    </div>
                    <div>
                      Loan:{' '}
                      <strong className="text-slate-200">{formatCurrency(rec.loanAmount, currency)}</strong>
                    </div>
                    <div>
                      Bureau:{' '}
                      <strong className="text-cyan-400">{rec.creditScore}</strong>
                    </div>
                    <div>
                      DTI:{' '}
                      <strong className="text-slate-200">{rec.dtiRatio}%</strong>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-800/60">
                    <span>{new Date(rec.createdAt).toLocaleString()}</span>
                    <span>{rec.employmentType}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
