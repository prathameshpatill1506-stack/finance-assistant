import React from 'react';
import { CurrencyCode } from '../types/financial';
import { ShieldAlert, Database, FileSpreadsheet, Sparkles, BookOpen } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  onOpenRecords: () => void;
  onOpenDocs: () => void;
  recordsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  onOpenRecords,
  onOpenDocs,
  recordsCount,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'loan', label: 'Loan Eligibility' },
    { id: 'credit', label: 'Credit Analyzer' },
    { id: 'emi', label: 'EMI Calculator' },
    { id: 'ai-tips', label: 'AI Guidance' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => setActiveTab('dashboard')}
          className="text-left font-bold tracking-tight text-slate-100 hover:text-cyan-400 transition-colors flex items-center gap-2 group cursor-pointer"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 font-black text-base shadow-sm group-hover:scale-105 transition-transform">
            FP
          </div>
          <span className="text-lg font-bold text-slate-100">FinPulse</span>
        </button>

        {/* Zone 2: Clean text navigation links */}
        <nav className="hidden md:flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 text-sm font-medium transition-colors whitespace-nowrap cursor-pointer rounded-md ${
                  isActive
                    ? 'text-cyan-300 bg-cyan-950/40 border border-cyan-800/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Currency Toggle */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-900/80 p-0.5 text-xs font-mono">
            <button
              onClick={() => setCurrency('INR')}
              className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                currency === 'INR'
                  ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              ₹ INR
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                currency === 'USD'
                  ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              $ USD
            </button>
          </div>

          {/* Architecture / Docs Trigger */}
          <button
            onClick={onOpenDocs}
            title="System Architecture & Docs"
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>Docs</span>
          </button>

          {/* Records Ledger / Google Sheets Sync Trigger */}
          <button
            onClick={onOpenRecords}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-100 bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Records</span>
            {recordsCount > 0 && (
              <span className="bg-emerald-500/20 text-emerald-300 text-[11px] px-1.5 py-0.2 rounded font-mono">
                {recordsCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around px-2 py-2 border-t border-slate-800/60 bg-slate-950/90 overflow-x-auto text-xs">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`px-2.5 py-1 rounded font-medium whitespace-nowrap ${
              activeTab === item.id ? 'text-cyan-300 bg-cyan-950/60' : 'text-slate-400'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  );
};
