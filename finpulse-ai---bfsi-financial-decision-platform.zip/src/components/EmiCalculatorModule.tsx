import React, { useState, useMemo } from 'react';
import { CurrencyCode, EmiInputs, EmiResult } from '../types/financial';
import { calculateEMI, formatCurrency, formatNumber } from '../utils/calculations';
import {
  Calculator,
  PieChart,
  Calendar,
  Download,
  DollarSign,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowRight,
  TrendingDown,
  Percent,
} from 'lucide-react';

interface EmiCalculatorModuleProps {
  currency: CurrencyCode;
  onConsultAI: () => void;
  sharedLoanAmount?: number;
}

export const EmiCalculatorModule: React.FC<EmiCalculatorModuleProps> = ({
  currency,
  onConsultAI,
  sharedLoanAmount,
}) => {
  // Pre-configured loan presets
  const presets = [
    { label: 'Home Loan', amount: 5000000, rate: 8.5, tenure: 20 },
    { label: 'Auto / Car Loan', amount: 1200000, rate: 9.25, tenure: 5 },
    { label: 'Personal Loan', amount: 500000, rate: 12.5, tenure: 3 },
    { label: 'Education Loan', amount: 2000000, rate: 9.0, tenure: 8 },
  ];

  const [inputs, setInputs] = useState<EmiInputs>({
    principal: sharedLoanAmount && sharedLoanAmount > 0 ? sharedLoanAmount : 2500000,
    annualInterestRate: 9.0,
    tenureYears: 15,
    prepaymentMonthly: 0,
  });

  const [tenureUnit, setTenureUnit] = useState<'years' | 'months'>('years');
  const [showAmortization, setShowAmortization] = useState(false);
  const [expandedYear, setExpandedYear] = useState<number | null>(null);

  // Compute EMI result dynamically
  const emiData: EmiResult = useMemo(() => {
    return calculateEMI(inputs);
  }, [inputs]);

  const handlePresetSelect = (p: (typeof presets)[0]) => {
    setInputs((prev) => ({
      ...prev,
      principal: p.amount,
      annualInterestRate: p.rate,
      tenureYears: p.tenure,
    }));
  };

  const exportAmortizationCSV = () => {
    if (!emiData.amortizationSchedule.length) return;

    const headers = [
      'Month',
      'Year',
      'Beginning Balance',
      'EMI Payment',
      'Principal Paid',
      'Interest Paid',
      'Ending Balance',
      'Total Interest To Date',
    ];

    const rows = emiData.amortizationSchedule.map((row) => [
      row.month,
      row.year,
      row.beginningBalance,
      row.emiPayment,
      row.principalPaid,
      row.interestPaid,
      row.endingBalance,
      row.totalInterestToDate,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `FinPulse_Amortization_Schedule_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8">
      {/* Module Title */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
          <Calculator className="w-4 h-4" />
          <span>Equated Monthly Installment Engine</span>
          <span className="text-slate-600">·</span>
          <span>Zero-Interest & Prepayment Enabled</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">Interactive EMI & Amortization Calculator</h1>
        <p className="text-sm text-slate-400 max-w-3xl">
          Calculate monthly loan installments with exact mathematical precision. Visualize the interest vs principal
          split, model early tenure reduction via prepayments, and inspect the year-by-year amortization breakdown.
        </p>
      </div>

      {/* Quick Presets */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-400 shrink-0 font-medium">Quick Presets:</span>
        {presets.map((preset) => (
          <button
            key={preset.label}
            onClick={() => handlePresetSelect(preset)}
            className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 hover:border-slate-700 transition-colors whitespace-nowrap cursor-pointer"
          >
            {preset.label} ({preset.rate}%)
          </button>
        ))}
      </div>

      {/* Main Grid: Inputs (Left) and Results (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* INPUTS (6 Columns) */}
        <div className="lg:col-span-6 glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <Percent className="w-4 h-4 text-blue-400" />
              <span>Loan Parameters</span>
            </h2>
            <span className="text-xs text-slate-400 font-mono">Real-time update</span>
          </div>

          <div className="space-y-6">
            {/* 1. Principal Loan Amount */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-300">Principal Loan Amount</label>
                <div className="flex items-center gap-1">
                  <span className="text-xs text-slate-400 font-mono">{currency === 'INR' ? '₹' : '$'}</span>
                  <input
                    type="number"
                    min="10000"
                    step="50000"
                    value={inputs.principal || ''}
                    onChange={(e) => setInputs({ ...inputs, principal: Number(e.target.value) })}
                    className="w-36 px-2.5 py-1 text-right rounded-lg glass-input text-sm font-mono font-bold text-cyan-300"
                  />
                </div>
              </div>
              <input
                type="range"
                min="50000"
                max="20000000"
                step="50000"
                value={inputs.principal}
                onChange={(e) => setInputs({ ...inputs, principal: Number(e.target.value) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>{formatCurrency(50000, currency)}</span>
                <span>{formatCurrency(10000000, currency)}</span>
                <span>{formatCurrency(20000000, currency)}</span>
              </div>
            </div>

            {/* 2. Annual Interest Rate */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-300">
                  Annual Interest Rate (% p.a.)
                  {inputs.annualInterestRate === 0 && (
                    <span className="ml-2 text-[10px] font-bold text-emerald-400">(0% Zero-Interest Financed)</span>
                  )}
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="30"
                    step="0.1"
                    value={inputs.annualInterestRate}
                    onChange={(e) => setInputs({ ...inputs, annualInterestRate: Number(e.target.value) })}
                    className="w-24 px-2.5 py-1 text-right rounded-lg glass-input text-sm font-mono font-bold text-blue-300"
                  />
                  <span className="text-xs text-slate-400">%</span>
                </div>
              </div>
              <input
                type="range"
                min="0"
                max="25"
                step="0.25"
                value={inputs.annualInterestRate}
                onChange={(e) => setInputs({ ...inputs, annualInterestRate: Number(e.target.value) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0% (Subvention)</span>
                <span>8.5% (Prime Home)</span>
                <span>14% (Unsecured)</span>
                <span>25%</span>
              </div>
            </div>

            {/* 3. Loan Tenure */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <label className="text-xs font-medium text-slate-300">Loan Tenure</label>
                  <div className="flex rounded-md border border-slate-800 bg-slate-900 p-0.5 text-[11px] font-mono">
                    <button
                      onClick={() => setTenureUnit('years')}
                      className={`px-2 py-0.5 rounded cursor-pointer ${
                        tenureUnit === 'years' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                      }`}
                    >
                      Years
                    </button>
                    <button
                      onClick={() => setTenureUnit('months')}
                      className={`px-2 py-0.5 rounded cursor-pointer ${
                        tenureUnit === 'months' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                      }`}
                    >
                      Months
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-1 font-mono text-sm font-bold text-slate-100">
                  {tenureUnit === 'years' ? (
                    <span>{inputs.tenureYears} Years</span>
                  ) : (
                    <span>{inputs.tenureYears * 12} Months</span>
                  )}
                </div>
              </div>

              <input
                type="range"
                min="1"
                max="30"
                step="1"
                value={inputs.tenureYears}
                onChange={(e) => setInputs({ ...inputs, tenureYears: Number(e.target.value) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>1 Year (12 Mo)</span>
                <span>15 Years (180 Mo)</span>
                <span>30 Years (360 Mo)</span>
              </div>
            </div>

            {/* 4. Prepayment / Extra Monthly Principal Simulator */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <TrendingDown className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Prepayment Simulator (Monthly Extra)</span>
                </span>
                <span className="font-mono text-emerald-400 font-bold">
                  +{formatCurrency(inputs.prepaymentMonthly || 0, currency)}/mo
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="50000"
                step="1000"
                value={inputs.prepaymentMonthly || 0}
                onChange={(e) => setInputs({ ...inputs, prepaymentMonthly: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[11px] text-slate-400">
                Adding voluntary extra principal alongside each regular EMI sharply reduces cumulative interest.
              </p>
            </div>
          </div>
        </div>

        {/* RESULTS PANEL (6 Columns) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-6">
            {/* Primary Monthly EMI Display */}
            <div className="p-5 rounded-xl bg-gradient-to-br from-slate-900 to-slate-900/90 border border-cyan-800/40 text-center space-y-1">
              <span className="text-xs uppercase tracking-wider text-slate-400 font-medium">Monthly Installment (EMI)</span>
              <div className="text-3xl sm:text-4xl font-extrabold font-mono text-cyan-300 tabular-nums">
                {formatCurrency(emiData.monthlyEmi, currency)}
              </div>
              <div className="text-xs text-slate-400">
                for {inputs.tenureYears * 12} installments at {inputs.annualInterestRate}% p.a.
              </div>
            </div>

            {/* Repayment Breakdown Cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                <span className="text-[11px] text-slate-400">Total Interest Payable</span>
                <div className="text-lg sm:text-xl font-bold font-mono text-amber-300 tabular-nums">
                  {formatCurrency(emiData.totalInterest, currency)}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  {emiData.interestRatioPercent}% of total cost
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                <span className="text-[11px] text-slate-400">Total Repayment (P + I)</span>
                <div className="text-lg sm:text-xl font-bold font-mono text-slate-100 tabular-nums">
                  {formatCurrency(emiData.totalRepayment, currency)}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">over full loan life</div>
              </div>
            </div>

            {/* Visual Breakdown Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  <span className="text-slate-300">Principal: {emiData.principalRatioPercent}%</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                  <span className="text-slate-300">Interest: {emiData.interestRatioPercent}%</span>
                </div>
              </div>

              <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden flex">
                <div
                  className="bg-cyan-400 h-full transition-all duration-300"
                  style={{ width: `${emiData.principalRatioPercent}%` }}
                />
                <div
                  className="bg-amber-400 h-full transition-all duration-300"
                  style={{ width: `${emiData.interestRatioPercent}%` }}
                />
              </div>
            </div>

            {/* Prepayment Impact Banner (if active) */}
            {emiData.prepaymentSavings && inputs.prepaymentMonthly! > 0 && (
              <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-800/60 space-y-2 text-xs">
                <div className="flex items-center justify-between text-emerald-300 font-bold">
                  <span>Prepayment Benefit Summary</span>
                  <span>Early Closure: {Math.round(emiData.prepaymentSavings.tenureReducedMonths / 12)} Yrs Earlier</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-300 font-mono">
                  <div>
                    Interest Saved:{' '}
                    <strong className="text-emerald-400">
                      {formatCurrency(emiData.prepaymentSavings.interestSaved, currency)}
                    </strong>
                  </div>
                  <div>
                    Revised Tenure:{' '}
                    <strong className="text-slate-100">
                      {emiData.prepaymentSavings.revisedTenureMonths} Months
                    </strong>
                  </div>
                </div>
              </div>
            )}

            {/* Toggle Amortization Schedule */}
            <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                onClick={() => setShowAmortization(!showAmortization)}
                className="w-full sm:w-auto px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition-colors cursor-pointer"
              >
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>{showAmortization ? 'Hide Amortization Table' : 'View Amortization Table'}</span>
                {showAmortization ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              <button
                onClick={exportAmortizationCSV}
                className="w-full sm:w-auto px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-800 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* AMORTIZATION SCHEDULE TABLE (When expanded) */}
      {showAmortization && (
        <div className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-4">
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-cyan-400" />
                <span>Annual Amortization Schedule</span>
              </h3>
              <p className="text-xs text-slate-400">
                Principal and interest amortization progression over the {inputs.tenureYears}-year lifespan.
              </p>
            </div>
            <button
              onClick={exportAmortizationCSV}
              className="self-start sm:self-auto px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 border border-slate-700 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Download Full Schedule (.csv)</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300 font-mono">
              <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Year</th>
                  <th className="py-3 px-4 text-right">Principal Paid</th>
                  <th className="py-3 px-4 text-right">Interest Paid</th>
                  <th className="py-3 px-4 text-right">Total Annual Payment</th>
                  <th className="py-3 px-4 text-right">Ending Balance</th>
                  <th className="py-3 px-4 text-center">Breakdown</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {emiData.yearlySummary.map((yearRow) => {
                  const isExpanded = expandedYear === yearRow.year;
                  const monthlyRows = emiData.amortizationSchedule.filter((r) => r.year === yearRow.year);

                  return (
                    <React.Fragment key={yearRow.year}>
                      <tr className="hover:bg-slate-900/40 transition-colors">
                        <td className="py-3 px-4 font-bold text-slate-100">Year {yearRow.year}</td>
                        <td className="py-3 px-4 text-right text-cyan-400 font-semibold tabular-nums">
                          {formatCurrency(yearRow.principalPaid, currency)}
                        </td>
                        <td className="py-3 px-4 text-right text-amber-400 font-semibold tabular-nums">
                          {formatCurrency(yearRow.interestPaid, currency)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-200 font-semibold tabular-nums">
                          {formatCurrency(yearRow.principalPaid + yearRow.interestPaid, currency)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-300 tabular-nums">
                          {formatCurrency(yearRow.endingBalance, currency)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <button
                            onClick={() => setExpandedYear(isExpanded ? null : yearRow.year)}
                            className="px-2 py-0.5 rounded text-[10px] text-cyan-400 hover:text-cyan-300 bg-cyan-950/40 border border-cyan-800/50 cursor-pointer"
                          >
                            {isExpanded ? 'Hide Months' : 'View Months'}
                          </button>
                        </td>
                      </tr>

                      {/* Expanded Monthly Sub-Rows */}
                      {isExpanded && (
                        <tr>
                          <td colSpan={6} className="p-3 bg-slate-950/80 border-y border-slate-800">
                            <div className="overflow-x-auto max-h-56">
                              <table className="w-full text-[11px] text-slate-400 font-mono">
                                <thead>
                                  <tr className="border-b border-slate-800 text-[10px] text-slate-500 uppercase">
                                    <th className="py-1 px-3">Month</th>
                                    <th className="py-1 px-3 text-right">Beginning Balance</th>
                                    <th className="py-1 px-3 text-right">EMI</th>
                                    <th className="py-1 px-3 text-right">Principal</th>
                                    <th className="py-1 px-3 text-right">Interest</th>
                                    <th className="py-1 px-3 text-right">Ending Balance</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {monthlyRows.map((mRow) => (
                                    <tr key={mRow.month} className="border-b border-slate-900">
                                      <td className="py-1.5 px-3 font-semibold text-slate-300">Mo {mRow.month}</td>
                                      <td className="py-1.5 px-3 text-right tabular-nums">
                                        {formatCurrency(mRow.beginningBalance, currency)}
                                      </td>
                                      <td className="py-1.5 px-3 text-right tabular-nums text-slate-200">
                                        {formatCurrency(mRow.emiPayment, currency)}
                                      </td>
                                      <td className="py-1.5 px-3 text-right tabular-nums text-cyan-400">
                                        {formatCurrency(mRow.principalPaid, currency)}
                                      </td>
                                      <td className="py-1.5 px-3 text-right tabular-nums text-amber-400">
                                        {formatCurrency(mRow.interestPaid, currency)}
                                      </td>
                                      <td className="py-1.5 px-3 text-right tabular-nums text-slate-300">
                                        {formatCurrency(mRow.endingBalance, currency)}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
