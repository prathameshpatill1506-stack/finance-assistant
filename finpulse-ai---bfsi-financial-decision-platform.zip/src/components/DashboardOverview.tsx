import React from 'react';
import { CurrencyCode, LoanInputs } from '../types/financial';
import { formatCurrency } from '../utils/calculations';
import {
  ShieldCheck,
  TrendingUp,
  CreditCard,
  Calculator,
  Sparkles,
  ArrowRight,
  AlertTriangle,
  FileSpreadsheet,
  CheckCircle2,
  Sliders,
  DollarSign,
  Activity,
  Layers,
} from 'lucide-react';

interface DashboardOverviewProps {
  onNavigate: (tab: string) => void;
  currency: CurrencyCode;
  sharedInputs: LoanInputs;
  setSharedInputs: React.Dispatch<React.SetStateAction<LoanInputs>>;
  recordsCount: number;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  onNavigate,
  currency,
  sharedInputs,
  setSharedInputs,
  recordsCount,
}) => {
  const { monthlyIncome, monthlyExpenses, existingEmi, creditScore, desiredLoanAmount } = sharedInputs;

  // Real-time quick health computations
  const netCashflow = monthlyIncome - monthlyExpenses - existingEmi;
  const dti = monthlyIncome > 0 ? Math.round((existingEmi / monthlyIncome) * 100) : 0;
  const foir = monthlyIncome > 0 ? Math.round(((existingEmi + monthlyExpenses) / monthlyIncome) * 100) : 0;

  // Credit Category
  const getCreditCategory = (score: number) => {
    if (score >= 750) return { label: 'Excellent', color: 'text-emerald-400', bg: 'bg-emerald-500/20' };
    if (score >= 700) return { label: 'Good', color: 'text-cyan-400', bg: 'bg-cyan-500/20' };
    if (score >= 650) return { label: 'Fair', color: 'text-amber-400', bg: 'bg-amber-500/20' };
    if (score >= 580) return { label: 'Needs Improvement', color: 'text-orange-400', bg: 'bg-orange-500/20' };
    return { label: 'High Risk', color: 'text-rose-400', bg: 'bg-rose-500/20' };
  };

  const creditStatus = getCreditCategory(creditScore);

  // Eligibility quick estimation score
  const quickEligibilityScore = Math.min(
    100,
    Math.max(
      15,
      Math.round(
        (monthlyIncome >= 80000 ? 30 : (monthlyIncome / 80000) * 30) +
          ((creditScore - 300) / 600) * 35 +
          Math.max(0, 1 - dti / 100) * 35
      )
    )
  );

  return (
    <div className="space-y-10">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden rounded-2xl glass-panel p-6 sm:p-10 border border-slate-800">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span>FinPulse BFSI Advisory Engine</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">Underwriting Estimates & Financial Intelligence</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-100 leading-tight">
            Institutional BFSI Intelligence for Smarter Financial Decisions
          </h1>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
            Evaluate loan borrowing capacity, analyze credit bureau risk drivers, calculate real-time EMI amortization,
            and generate personalized financial optimization guidance backed by AI.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('loan')}
              className="px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm flex items-center gap-2 transition-transform hover:scale-[1.02] cursor-pointer shadow-lg shadow-cyan-500/10"
            >
              <span>Check Loan Eligibility</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('emi')}
              className="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm flex items-center gap-2 border border-slate-700 transition-colors cursor-pointer"
            >
              <Calculator className="w-4 h-4 text-cyan-400" />
              <span>Calculate EMI</span>
            </button>
            <button
              onClick={() => onNavigate('ai-tips')}
              className="px-5 py-2.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-cyan-300 font-semibold text-sm flex items-center gap-2 border border-cyan-800/60 transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Get AI Financial Tips</span>
            </button>
          </div>
        </div>

        {/* Subtle Decorative backdrop lighting */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* 2. Educational & Legal Disclaimer Banner */}
      <div className="flex items-start gap-3 p-4 rounded-xl border border-amber-900/40 bg-amber-950/20 text-amber-200/90 text-xs sm:text-sm">
        <AlertTriangle className="w-5 h-5 shrink-0 text-amber-400 mt-0.5" />
        <div className="space-y-1 leading-relaxed">
          <span className="font-semibold text-amber-300">Educational & Informational Notice:</span>
          <p className="text-amber-200/80">
            Calculations and AI guidance provided by this platform are analytical estimates designed to assist your
            financial planning. They do not constitute official bank loan approvals, credit bureau scores, or formal
            lending commitments. Always verify major financial commitments with accredited banking professionals.
          </p>
        </div>
      </div>

      {/* 3. Financial Health Snapshot & Live Indicators */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-100">Financial Health Snapshot</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Interactive snapshot reflecting your current monthly cashflows and debt obligations
            </p>
          </div>
          <button
            onClick={() => onNavigate('loan')}
            className="self-start sm:self-auto text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
          >
            <span>Edit Full Profile in Loan Module</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Financial Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Monthly Income */}
          <div className="glass-panel p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 font-medium">Monthly Gross Income</span>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {formatCurrency(monthlyIncome, currency)}
            </div>
            <div className="text-[11px] text-slate-400">Baseline earnings before deductions</div>
          </div>

          {/* Monthly Expenses */}
          <div className="glass-panel p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 font-medium">Monthly Living Expenses</span>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {formatCurrency(monthlyExpenses, currency)}
            </div>
            <div className="text-[11px] text-slate-400">
              {monthlyIncome > 0 ? Math.round((monthlyExpenses / monthlyIncome) * 100) : 0}% of monthly income
            </div>
          </div>

          {/* Existing EMIs */}
          <div className="glass-panel p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 font-medium">Existing Monthly EMIs</span>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {formatCurrency(existingEmi, currency)}
            </div>
            <div className="text-[11px] text-slate-400">
              DTI: <span className="font-semibold text-cyan-400">{dti}%</span> of income
            </div>
          </div>

          {/* Credit Score */}
          <div className="glass-panel p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400 font-medium">Credit Bureau Score</span>
              <span className={`text-[11px] font-semibold ${creditStatus.color}`}>{creditStatus.label}</span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100 tabular-nums flex items-baseline gap-2">
              <span>{creditScore}</span>
              <span className="text-xs text-slate-400 font-normal">/ 900</span>
            </div>
            <div className="text-[11px] text-slate-400">Estimated bureau standing</div>
          </div>
        </div>

        {/* Visual Progress Indicators & Debt Stress Gauges */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* Indicator 1: Loan Eligibility Capacity */}
          <div className="glass-panel p-5 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300">Loan Eligibility Index</span>
              <span className="font-mono text-cyan-400 font-bold">{quickEligibilityScore} / 100</span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${quickEligibilityScore}%` }}
              />
            </div>
            <p className="text-xs text-slate-400">
              {quickEligibilityScore >= 75
                ? 'High approval probability under institutional underwriting parameters.'
                : quickEligibilityScore >= 60
                ? 'Moderate approval viability; lowering existing liabilities will increase headroom.'
                : 'Elevated debt or sub-optimal credit rating may trigger underwriting scrutiny.'}
            </p>
          </div>

          {/* Indicator 2: Debt-to-Income (DTI) Stress */}
          <div className="glass-panel p-5 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300">Debt-to-Income (DTI) Level</span>
              <span
                className={`font-mono font-bold ${
                  dti <= 35 ? 'text-emerald-400' : dti <= 50 ? 'text-amber-400' : 'text-rose-400'
                }`}
              >
                {dti}% (Benchmark &lt; 35%)
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  dti <= 35 ? 'bg-emerald-400' : dti <= 50 ? 'bg-amber-400' : 'bg-rose-500'
                }`}
                style={{ width: `${Math.min(100, dti * 1.5)}%` }}
              />
            </div>
            <p className="text-xs text-slate-400">
              {dti <= 35
                ? 'Healthy debt obligations. Lenders consider you a low credit default risk.'
                : dti <= 50
                ? 'Moderate debt servicing. Additional borrowing will push into high-risk tiers.'
                : 'Stretched debt servicing. High vulnerability to unforeseen income shocks.'}
            </p>
          </div>

          {/* Indicator 3: Net Free Cashflow Reserve */}
          <div className="glass-panel p-5 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300">Net Disposable Cashflow</span>
              <span
                className={`font-mono font-bold ${netCashflow >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}
              >
                {formatCurrency(netCashflow, currency)}
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  netCashflow >= 0 ? 'bg-emerald-400' : 'bg-rose-500'
                }`}
                style={{
                  width: `${Math.min(100, Math.max(5, (netCashflow / (monthlyIncome || 1)) * 100))}%`,
                }}
              />
            </div>
            <p className="text-xs text-slate-400">
              {netCashflow > 0
                ? `You retain ${Math.round((netCashflow / monthlyIncome) * 100)}% of gross monthly income for savings and emergencies.`
                : 'Living expenses and debt obligations exceed monthly income. Action needed.'}
            </p>
          </div>
        </div>
      </section>

      {/* 4. Quick-Access Module Cards */}
      <section className="space-y-4">
        <h2 className="text-xl sm:text-2xl font-bold text-slate-100">Explore Core Financial Modules</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Module 1: Loan Eligibility */}
          <div
            onClick={() => onNavigate('loan')}
            className="group glass-panel p-6 rounded-xl border border-slate-800 hover:border-cyan-500/40 transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-4 hover:translate-y-[-2px]"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                <TrendingUp className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                Loan Eligibility Checker
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Determine your estimated borrowing capacity, FOIR thresholds, positive lending factors, and debt-to-income benchmarks.
              </p>
            </div>
            <div className="pt-2 flex items-center text-xs font-semibold text-cyan-400 group-hover:translate-x-1 transition-transform">
              <span>Evaluate Capacity</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </div>

          {/* Module 2: Credit Score Analyzer */}
          <div
            onClick={() => onNavigate('credit')}
            className="group glass-panel p-6 rounded-xl border border-slate-800 hover:border-cyan-500/40 transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-4 hover:translate-y-[-2px]"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                <CreditCard className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                Credit Score Analyzer
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Deep-dive into payment track record, credit card utilization ratios, hard inquiries, and 30/60/90-day score acceleration plans.
              </p>
            </div>
            <div className="pt-2 flex items-center text-xs font-semibold text-emerald-400 group-hover:translate-x-1 transition-transform">
              <span>Analyze Credit Risk</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </div>

          {/* Module 3: EMI Calculator */}
          <div
            onClick={() => onNavigate('emi')}
            className="group glass-panel p-6 rounded-xl border border-slate-800 hover:border-cyan-500/40 transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-4 hover:translate-y-[-2px]"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                <Calculator className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-100 group-hover:text-blue-300 transition-colors">
                EMI Calculator
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Calculate precise monthly installments, interest breakdowns, dynamic amortization tables, and prepayment savings.
              </p>
            </div>
            <div className="pt-2 flex items-center text-xs font-semibold text-blue-400 group-hover:translate-x-1 transition-transform">
              <span>Calculate Repayments</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </div>

          {/* Module 4: AI Financial Tips */}
          <div
            onClick={() => onNavigate('ai-tips')}
            className="group glass-panel p-6 rounded-xl border border-slate-800 hover:border-cyan-500/40 transition-all duration-200 cursor-pointer flex flex-col justify-between space-y-4 hover:translate-y-[-2px]"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-100 group-hover:text-purple-300 transition-colors">
                AI Financial Guidance
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Receive personalized BFSI advisory powered by AI, featuring debt avalanche strategies, risk mitigations, and checklists.
              </p>
            </div>
            <div className="pt-2 flex items-center text-xs font-semibold text-purple-400 group-hover:translate-x-1 transition-transform">
              <span>Generate AI Insights</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
