import React, { useState, useMemo } from 'react';
import { CreditAnalyzerInputs, CreditAnalysisResult } from '../types/financial';
import { analyzeCreditScore } from '../utils/calculations';
import {
  CreditCard,
  ShieldAlert,
  AlertTriangle,
  TrendingUp,
  Clock,
  PieChart,
  Calendar,
  CheckCircle,
  HelpCircle,
  Sparkles,
  Zap,
} from 'lucide-react';

interface CreditScoreModuleProps {
  onConsultAI: () => void;
  sharedCreditScore: number;
  onScoreUpdated: (score: number) => void;
}

export const CreditScoreModule: React.FC<CreditScoreModuleProps> = ({
  onConsultAI,
  sharedCreditScore,
  onScoreUpdated,
}) => {
  const [inputs, setInputs] = useState<CreditAnalyzerInputs>({
    creditScore: sharedCreditScore || 720,
    paymentHistoryPercent: 98,
    creditUtilizationPercent: 28,
    activeLoansCount: 2,
    creditCardsCount: 3,
    creditHistoryYears: 5,
    hardInquiriesLast6Months: 1,
    latePaymentsCount: 0,
  });

  const [activeTabRoadmap, setActiveTabRoadmap] = useState<'30' | '60' | '90'>('30');
  const [simulatedPaydown, setSimulatedPaydown] = useState<number>(0);

  // Compute analysis result
  const analysis: CreditAnalysisResult = useMemo(() => {
    // If user interacts with simulator, compute simulated outcome
    const effectiveInputs = {
      ...inputs,
      creditUtilizationPercent: Math.max(5, inputs.creditUtilizationPercent - simulatedPaydown),
    };
    return analyzeCreditScore(effectiveInputs);
  }, [inputs, simulatedPaydown]);

  const handleInputChange = (field: keyof CreditAnalyzerInputs, val: number) => {
    const updated = { ...inputs, [field]: val };
    setInputs(updated);
    if (field === 'creditScore') {
      onScoreUpdated(val);
    }
  };

  const getCategoryColor = (cat: CreditAnalysisResult['category']) => {
    switch (cat) {
      case 'Excellent':
        return { text: 'text-emerald-400', bg: 'bg-emerald-950/40 border-emerald-800' };
      case 'Good':
        return { text: 'text-cyan-400', bg: 'bg-cyan-950/40 border-cyan-800' };
      case 'Fair':
        return { text: 'text-amber-400', bg: 'bg-amber-950/40 border-amber-800' };
      case 'Needs Improvement':
        return { text: 'text-orange-400', bg: 'bg-orange-950/40 border-orange-800' };
      case 'High Risk':
        return { text: 'text-rose-400', bg: 'bg-rose-950/40 border-rose-800' };
    }
  };

  const catStyle = getCategoryColor(analysis.category);

  return (
    <div className="space-y-8">
      {/* Module Title */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
          <CreditCard className="w-4 h-4" />
          <span>Bureau Scoring Diagnostic Engine</span>
          <span className="text-slate-600">·</span>
          <span>5-Pillar Risk Evaluation</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">Credit Score & Financial Risk Analyzer</h1>
        <p className="text-sm text-slate-400 max-w-3xl">
          Analyze the core drivers of institutional credit standing, model repayment track record, diagnose credit
          utilization drag, and plan a targeted credit enhancement roadmap.
        </p>
      </div>

      {/* Bureau Disclaimer Notice */}
      <div className="p-3.5 rounded-xl border border-slate-800 bg-slate-900/60 text-xs text-slate-400 flex items-start gap-2.5">
        <ShieldAlert className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <span>
          <strong className="text-slate-200">Bureau Transparency Notice:</strong> Official credit scores are generated
          exclusively by authorized national credit bureaus (such as CIBIL, Experian, Equifax, TransUnion). This tool
          models algorithmic risk weighting principles to help you understand score fluctuations and improve your debt
          standing.
        </span>
      </div>

      {/* Main Grid: Inputs (Left) and Diagnostic Breakdown (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* INPUTS PANEL (6 Columns) */}
        <div className="lg:col-span-6 glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Credit Bureau Tradeline Variables</span>
            </h2>
            <span className="text-xs text-slate-400 font-mono">Dynamic sliders</span>
          </div>

          <div className="space-y-5">
            {/* Primary Credit Score */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-300">
                  Current Credit Score: <span className="text-base font-bold font-mono text-cyan-300">{inputs.creditScore}</span>
                </label>
                <span className={`text-xs font-bold px-2 py-0.5 rounded border ${catStyle.bg} ${catStyle.text}`}>
                  {analysis.category}
                </span>
              </div>
              <input
                type="range"
                min="300"
                max="900"
                step="5"
                value={inputs.creditScore}
                onChange={(e) => handleInputChange('creditScore', Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>300 (Poor)</span>
                <span>650 (Fair)</span>
                <span>750 (Prime)</span>
                <span>900 (Excellent)</span>
              </div>
            </div>

            {/* Payment History & Utilization Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {/* Payment History % */}
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-300">On-Time Payments</span>
                  <span className="text-xs font-mono font-bold text-slate-100">{inputs.paymentHistoryPercent}%</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={inputs.paymentHistoryPercent}
                  onChange={(e) => handleInputChange('paymentHistoryPercent', Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">35% of overall score weight</span>
              </div>

              {/* Credit Card Utilization % */}
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-300">Revolving Utilization</span>
                  <span
                    className={`text-xs font-mono font-bold ${
                      inputs.creditUtilizationPercent <= 30 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {inputs.creditUtilizationPercent}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={inputs.creditUtilizationPercent}
                  onChange={(e) => handleInputChange('creditUtilizationPercent', Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-[10px] text-slate-400 block">Optimal threshold &lt; 30%</span>
              </div>
            </div>

            {/* Tradeline Details Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Active Loans</label>
                <input
                  type="number"
                  min="0"
                  max="20"
                  value={inputs.activeLoansCount}
                  onChange={(e) => handleInputChange('activeLoansCount', Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg glass-input text-xs sm:text-sm font-mono tabular-nums"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Credit Cards</label>
                <input
                  type="number"
                  min="0"
                  max="20"
                  value={inputs.creditCardsCount}
                  onChange={(e) => handleInputChange('creditCardsCount', Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg glass-input text-xs sm:text-sm font-mono tabular-nums"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">History Age (Yrs)</label>
                <input
                  type="number"
                  min="0.5"
                  max="30"
                  step="0.5"
                  value={inputs.creditHistoryYears}
                  onChange={(e) => handleInputChange('creditHistoryYears', Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg glass-input text-xs sm:text-sm font-mono tabular-nums"
                />
              </div>
            </div>

            {/* Inquiries & Late Payments */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Hard Inquiries (Last 6 Months)
                </label>
                <input
                  type="number"
                  min="0"
                  max="15"
                  value={inputs.hardInquiriesLast6Months}
                  onChange={(e) => handleInputChange('hardInquiriesLast6Months', Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg glass-input text-xs sm:text-sm font-mono tabular-nums"
                />
                <span className="text-[10px] text-slate-400">&gt;2 inquiries can suppress scores</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Late Payments / Delinquencies
                </label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  value={inputs.latePaymentsCount}
                  onChange={(e) => handleInputChange('latePaymentsCount', Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg glass-input text-xs sm:text-sm font-mono tabular-nums"
                />
                <span className="text-[10px] text-slate-400">Past 24 months 30+ day lapses</span>
              </div>
            </div>

            {/* "What-If" Utilization Simulator */}
            <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-800/40 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-cyan-300 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Simulation: Pay Down Credit Card Debt</span>
                </span>
                <span className="font-mono text-cyan-300 font-bold">-{simulatedPaydown}% Utilization</span>
              </div>
              <input
                type="range"
                min="0"
                max={Math.min(50, inputs.creditUtilizationPercent)}
                step="5"
                value={simulatedPaydown}
                onChange={(e) => setSimulatedPaydown(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[11px] text-slate-400">
                Drag to simulate how rapidly paying off revolving card balances improves utilization scoring.
              </p>
            </div>
          </div>
        </div>

        {/* DIAGNOSTIC RESULTS (6 Columns) */}
        <div className="lg:col-span-6 space-y-6">
          {/* Main Risk Status Card */}
          <div className="glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
              <div className="space-y-0.5">
                <span className="text-xs text-slate-400">Estimated Bureau Standing</span>
                <div className="text-2xl font-bold font-mono text-slate-100 flex items-baseline gap-2">
                  <span>{analysis.score}</span>
                  <span className="text-xs text-slate-500 font-normal">/ 900</span>
                </div>
              </div>
              <div className="text-right space-y-0.5">
                <span className="text-xs text-slate-400">Approval Viability</span>
                <div className="text-sm font-bold text-emerald-400">{analysis.approvalProbability}</div>
              </div>
            </div>

            {/* 5 Core Pillars */}
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <PieChart className="w-3.5 h-3.5 text-cyan-400" />
                <span>5-Pillar Credit Composition</span>
              </h3>

              <div className="space-y-2.5">
                {analysis.pillars.map((pillar) => (
                  <div key={pillar.name} className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-200">{pillar.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">({pillar.weightPercent}% wt)</span>
                      </div>
                      <span
                        className={`font-semibold font-mono text-xs ${
                          pillar.status === 'Excellent'
                            ? 'text-emerald-400'
                            : pillar.status === 'Good'
                            ? 'text-cyan-400'
                            : pillar.status === 'Fair'
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {pillar.status} ({pillar.scoreValue}/100)
                      </span>
                    </div>

                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          pillar.status === 'Excellent'
                            ? 'bg-emerald-400'
                            : pillar.status === 'Good'
                            ? 'bg-cyan-400'
                            : pillar.status === 'Fair'
                            ? 'bg-amber-400'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${pillar.scoreValue}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>{pillar.comment}</span>
                      <span className="text-[10px] text-slate-500">{pillar.benchmark}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pillar Deep Insights */}
            <div className="space-y-3 pt-2 border-t border-slate-800/80">
              <h3 className="text-xs font-semibold text-slate-300">Targeted Bureau Risk Insights</h3>
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-800/70 space-y-1">
                  <span className="font-semibold text-cyan-300">Credit Card Utilization Impact:</span>
                  <p className="text-slate-300 leading-relaxed">{analysis.insights.utilizationInsight}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-800/70 space-y-1">
                  <span className="font-semibold text-emerald-300">Payment Velocity Record:</span>
                  <p className="text-slate-300 leading-relaxed">{analysis.insights.paymentHistoryInsight}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-800/70 space-y-1">
                  <span className="font-semibold text-purple-300">Tradeline Depth & Mix:</span>
                  <p className="text-slate-300 leading-relaxed">{analysis.insights.debtManagementInsight}</p>
                </div>
              </div>
            </div>

            {/* 30/60/90 Day Score Acceleration Roadmap */}
            <div className="space-y-3 pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Improvement Roadmap</span>
                </h3>
                {/* Segmented control tabs */}
                <div className="flex items-center p-0.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                  <button
                    onClick={() => setActiveTabRoadmap('30')}
                    className={`px-2.5 py-1 rounded cursor-pointer ${
                      activeTabRoadmap === '30' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                    }`}
                  >
                    30 Days
                  </button>
                  <button
                    onClick={() => setActiveTabRoadmap('60')}
                    className={`px-2.5 py-1 rounded cursor-pointer ${
                      activeTabRoadmap === '60' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                    }`}
                  >
                    60 Days
                  </button>
                  <button
                    onClick={() => setActiveTabRoadmap('90')}
                    className={`px-2.5 py-1 rounded cursor-pointer ${
                      activeTabRoadmap === '90' ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'
                    }`}
                  >
                    90 Days
                  </button>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
                <ul className="space-y-2 text-xs text-slate-300">
                  {(activeTabRoadmap === '30'
                    ? analysis.actionableRoadmap.thirtyDays
                    : activeTabRoadmap === '60'
                    ? analysis.actionableRoadmap.sixtyDays
                    : analysis.actionableRoadmap.ninetyDays
                  ).map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Quick Action to AI Consultation */}
            <button
              onClick={onConsultAI}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs flex items-center justify-center gap-2 border border-cyan-800/50 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ask AI for a Custom Score Recovery Strategy</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
