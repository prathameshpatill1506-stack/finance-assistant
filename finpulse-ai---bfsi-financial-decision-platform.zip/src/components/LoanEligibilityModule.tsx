import React, { useState, useEffect } from 'react';
import { CurrencyCode, LoanInputs, EligibilityResult, EmploymentType } from '../types/financial';
import { calculateLoanEligibility, formatCurrency } from '../utils/calculations';
import {
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Save,
  Sparkles,
  ArrowRight,
  UserCheck,
  Building,
  Briefcase,
  AlertTriangle,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface LoanEligibilityModuleProps {
  currency: CurrencyCode;
  sharedInputs: LoanInputs;
  setSharedInputs: React.Dispatch<React.SetStateAction<LoanInputs>>;
  onConsultAI: () => void;
  onRecordSaved: () => void;
}

export const LoanEligibilityModule: React.FC<LoanEligibilityModuleProps> = ({
  currency,
  sharedInputs,
  setSharedInputs,
  onConsultAI,
  onRecordSaved,
}) => {
  const [formData, setFormData] = useState<LoanInputs>(sharedInputs);
  const [applicantName, setApplicantName] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [result, setResult] = useState<EligibilityResult | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Sync with shared state
  useEffect(() => {
    setFormData(sharedInputs);
  }, [sharedInputs]);

  // Run calculation immediately on load or formData update
  useEffect(() => {
    const res = calculateLoanEligibility(formData);
    setResult(res);
  }, [formData]);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};

    if (!formData.monthlyIncome || formData.monthlyIncome <= 0) {
      errs.monthlyIncome = 'Monthly gross income must be greater than zero.';
    } else if (formData.monthlyIncome < 10000 && currency === 'INR') {
      errs.monthlyIncome = 'Minimum viable monthly income for formal lending is typically ₹10,000.';
    }

    if (!formData.desiredLoanAmount || formData.desiredLoanAmount <= 0) {
      errs.desiredLoanAmount = 'Desired loan amount is required.';
    }

    if (!formData.age || formData.age < 18 || formData.age > 75) {
      errs.age = 'Applicant age must be between 18 and 75.';
    }

    if (formData.loanTenureYears < 1 || formData.loanTenureYears > 35) {
      errs.loanTenureYears = 'Tenure must be between 1 and 35 years.';
    }

    if (formData.creditScore < 300 || formData.creditScore > 900) {
      errs.creditScore = 'Credit bureau score must be between 300 and 900.';
    }

    if (formData.existingEmi < 0) {
      errs.existingEmi = 'Existing EMI cannot be negative.';
    }

    if (formData.monthlyExpenses < 0) {
      errs.monthlyExpenses = 'Monthly expenses cannot be negative.';
    }

    if (formData.employmentDurationYears < 0) {
      errs.employmentDurationYears = 'Employment duration cannot be negative.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleInputChange = (field: keyof LoanInputs, value: any) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    setSharedInputs(updated);
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const handleSaveAssessment = async () => {
    if (!validate() || !result) return;
    setIsSaving(true);
    setSaveSuccessMsg(null);

    try {
      const response = await fetch('/api/records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          applicantName: applicantName || 'Self Assessment',
          monthlyIncome: formData.monthlyIncome,
          monthlyExpenses: formData.monthlyExpenses,
          existingEmi: formData.existingEmi,
          creditScore: formData.creditScore,
          loanAmount: formData.desiredLoanAmount,
          loanTenureYears: formData.loanTenureYears,
          estimatedEmi: result.maxMonthlyEmiCapacity,
          eligibilityStatus: result.status,
          riskCategory: result.riskCategory,
          dtiRatio: result.dtiRatio,
          employmentType: formData.employmentType,
          notes: `Score: ${result.score}/100. Max Eligible: ${formatCurrency(
            result.estimatedEligibleLoanAmount,
            currency
          )}`,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setSaveSuccessMsg(
          data.googleSheetSynced
            ? 'Assessment recorded & synced with Google Sheets!'
            : 'Assessment saved to records ledger.'
        );
        onRecordSaved();
        setTimeout(() => setSaveSuccessMsg(null), 4000);
      }
    } catch (err: any) {
      console.error('Failed to save assessment:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const getStatusBadge = (status: EligibilityResult['status']) => {
    switch (status) {
      case 'High':
        return {
          label: 'Strong Eligibility',
          sub: 'High Approval Viability',
          color: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/80',
        };
      case 'Moderate':
        return {
          label: 'Moderate Eligibility',
          sub: 'Standard Underwriting Parameters',
          color: 'text-cyan-400 bg-cyan-950/60 border-cyan-800/80',
        };
      case 'Borderline':
        return {
          label: 'Borderline Eligibility',
          sub: 'High Debt / Elevated Risk Flag',
          color: 'text-amber-400 bg-amber-950/60 border-amber-800/80',
        };
      case 'Ineligible':
        return {
          label: 'High Underwriting Risk',
          sub: 'Restructuring / Collateral Recommended',
          color: 'text-rose-400 bg-rose-950/60 border-rose-800/80',
        };
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400">
          <TrendingUp className="w-4 h-4" />
          <span>Rule-Based Underwriting Model</span>
          <span className="text-slate-600">·</span>
          <span>Configurable Risk Weightings</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">Loan Eligibility & Borrowing Power</h1>
        <p className="text-sm text-slate-400 max-w-3xl">
          Evaluate your maximum borrowing capacity against institutional Fixed Obligation to Income (FOIR) standards,
          credit bureau thresholds, and employment stability guidelines.
        </p>
      </div>

      {/* Main Grid: Form (Left) & Results (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* FORM (7 Columns) */}
        <div className="lg:col-span-7 glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Applicant Financial Profile</span>
            </h2>
            <span className="text-xs text-slate-400">All fields validated client-side</span>
          </div>

          <div className="space-y-5">
            {/* Optional Applicant Identifier */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Applicant Name / Identifier (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. John Doe / Assessment 1"
                value={applicantName}
                onChange={(e) => setApplicantName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg glass-input text-sm"
              />
            </div>

            {/* Income & Desired Loan Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Monthly Gross Income <span className="text-cyan-400">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-mono">
                    {currency === 'INR' ? '₹' : '$'}
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="5000"
                    value={formData.monthlyIncome || ''}
                    onChange={(e) => handleInputChange('monthlyIncome', Number(e.target.value))}
                    className="w-full pl-8 pr-3.5 py-2 rounded-lg glass-input text-sm font-mono tabular-nums"
                    placeholder="75000"
                  />
                </div>
                {errors.monthlyIncome && <p className="text-xs text-rose-400 mt-1">{errors.monthlyIncome}</p>}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Desired Loan Amount <span className="text-cyan-400">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-mono">
                    {currency === 'INR' ? '₹' : '$'}
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="50000"
                    value={formData.desiredLoanAmount || ''}
                    onChange={(e) => handleInputChange('desiredLoanAmount', Number(e.target.value))}
                    className="w-full pl-8 pr-3.5 py-2 rounded-lg glass-input text-sm font-mono tabular-nums"
                    placeholder="2500000"
                  />
                </div>
                {errors.desiredLoanAmount && <p className="text-xs text-rose-400 mt-1">{errors.desiredLoanAmount}</p>}
              </div>
            </div>

            {/* Existing Obligations & Living Expenses */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Existing Monthly EMIs <span className="text-cyan-400">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-mono">
                    {currency === 'INR' ? '₹' : '$'}
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={formData.existingEmi ?? ''}
                    onChange={(e) => handleInputChange('existingEmi', Number(e.target.value))}
                    className="w-full pl-8 pr-3.5 py-2 rounded-lg glass-input text-sm font-mono tabular-nums"
                    placeholder="12000"
                  />
                </div>
                {errors.existingEmi && <p className="text-xs text-rose-400 mt-1">{errors.existingEmi}</p>}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Monthly Living Expenses <span className="text-cyan-400">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-mono">
                    {currency === 'INR' ? '₹' : '$'}
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={formData.monthlyExpenses ?? ''}
                    onChange={(e) => handleInputChange('monthlyExpenses', Number(e.target.value))}
                    className="w-full pl-8 pr-3.5 py-2 rounded-lg glass-input text-sm font-mono tabular-nums"
                    placeholder="25000"
                  />
                </div>
                {errors.monthlyExpenses && <p className="text-xs text-rose-400 mt-1">{errors.monthlyExpenses}</p>}
              </div>
            </div>

            {/* Tenure & Credit Score */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-slate-300">
                    Loan Tenure (Years): <span className="font-mono text-cyan-400">{formData.loanTenureYears} yrs</span>
                  </label>
                  <span className="text-[11px] text-slate-500 font-mono">{formData.loanTenureYears * 12} mo</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={formData.loanTenureYears}
                  onChange={(e) => handleInputChange('loanTenureYears', Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                {errors.loanTenureYears && <p className="text-xs text-rose-400 mt-1">{errors.loanTenureYears}</p>}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-slate-300">
                    Credit Bureau Score: <span className="font-mono text-cyan-400">{formData.creditScore}</span>
                  </label>
                  <span className="text-[11px] text-slate-500 font-mono">300 - 900</span>
                </div>
                <input
                  type="range"
                  min="300"
                  max="900"
                  step="5"
                  value={formData.creditScore}
                  onChange={(e) => handleInputChange('creditScore', Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                />
                {errors.creditScore && <p className="text-xs text-rose-400 mt-1">{errors.creditScore}</p>}
              </div>
            </div>

            {/* Age, Employment Type, Duration */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Applicant Age <span className="text-cyan-400">*</span>
                </label>
                <input
                  type="number"
                  min="18"
                  max="75"
                  value={formData.age || ''}
                  onChange={(e) => handleInputChange('age', Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-lg glass-input text-sm font-mono tabular-nums"
                  placeholder="32"
                />
                {errors.age && <p className="text-xs text-rose-400 mt-1">{errors.age}</p>}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Employment Type</label>
                <select
                  value={formData.employmentType}
                  onChange={(e) => handleInputChange('employmentType', e.target.value as EmploymentType)}
                  className="w-full px-3 py-2 rounded-lg glass-input text-xs sm:text-sm bg-slate-900"
                >
                  <option value="Salaried">Salaried (Corporate / Govt)</option>
                  <option value="Self-Employed Professional">Self-Employed Professional (Doctor/CA/Law)</option>
                  <option value="Self-Employed Business">Self-Employed Business Owner</option>
                  <option value="Freelancer / Gig Economy">Freelancer / Independent</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Current Role Tenure (Yrs)</label>
                <input
                  type="number"
                  min="0"
                  step="0.5"
                  value={formData.employmentDurationYears ?? ''}
                  onChange={(e) => handleInputChange('employmentDurationYears', Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-lg glass-input text-sm font-mono tabular-nums"
                  placeholder="3.5"
                />
              </div>
            </div>

            {/* Co-Applicant Booster Toggle */}
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="text-xs font-semibold text-slate-200">Add Creditworthy Co-Applicant</span>
                <p className="text-[11px] text-slate-400">
                  Adds secondary income support, expanding allowable FOIR by 5%
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.hasCoApplicant || false}
                  onChange={(e) => handleInputChange('hasCoApplicant', e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
              </label>
            </div>
          </div>
        </div>

        {/* RESULTS PANEL (5 Columns) */}
        <div className="lg:col-span-5 space-y-6">
          {result && (
            <div className="glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-6">
              {/* Status Header */}
              <div className="space-y-3 pb-4 border-b border-slate-800/80">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400 font-medium">Estimated Eligibility Result</span>
                  <span className="font-mono text-xs text-cyan-400 font-bold">
                    Score: {result.score} / 100
                  </span>
                </div>

                {(() => {
                  const badge = getStatusBadge(result.status);
                  return (
                    <div className={`p-4 rounded-xl border ${badge.color} space-y-1`}>
                      <div className="text-lg font-bold flex items-center justify-between">
                        <span>{badge.label}</span>
                        <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-900/60 border border-slate-700">
                          {result.riskCategory}
                        </span>
                      </div>
                      <p className="text-xs opacity-90">{badge.sub}</p>
                    </div>
                  );
                })()}
              </div>

              {/* Core Output Numbers */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                  <span className="text-[11px] text-slate-400">Max Eligible Loan</span>
                  <div className="text-lg sm:text-xl font-bold font-mono text-cyan-300 tabular-nums">
                    {formatCurrency(result.estimatedEligibleLoanAmount, currency)}
                  </div>
                  <span className="text-[10px] text-slate-500">at ~9.25% p.a. benchmark</span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                  <span className="text-[11px] text-slate-400">Max New EMI Capacity</span>
                  <div className="text-lg sm:text-xl font-bold font-mono text-slate-100 tabular-nums">
                    {formatCurrency(result.maxMonthlyEmiCapacity, currency)}
                  </div>
                  <span className="text-[10px] text-slate-500">per month capacity</span>
                </div>
              </div>

              {/* DTI Gauge Bar */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Debt-To-Income (DTI)</span>
                  <span
                    className={`font-mono font-bold ${
                      result.dtiRatio <= 35 ? 'text-emerald-400' : result.dtiRatio <= 50 ? 'text-amber-400' : 'text-rose-400'
                    }`}
                  >
                    {result.dtiRatio}% (Target &lt; 35%)
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      result.dtiRatio <= 35 ? 'bg-emerald-400' : result.dtiRatio <= 50 ? 'bg-amber-400' : 'bg-rose-500'
                    }`}
                    style={{ width: `${Math.min(100, result.dtiRatio * 1.5)}%` }}
                  />
                </div>
              </div>

              {/* Scoring Breakdown Accordion/Grid */}
              <div className="space-y-2 pt-2 border-t border-slate-800/80">
                <span className="text-xs font-semibold text-slate-300">Underwriting Component Weights</span>
                <div className="space-y-1.5 text-xs text-slate-400 font-mono">
                  <div className="flex justify-between py-0.5">
                    <span>Income Level (25 pts max)</span>
                    <span className="text-slate-200">{result.breakdown.incomeFactorScore} pts</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>Credit Bureau Standing (25 pts max)</span>
                    <span className="text-slate-200">{result.breakdown.creditFactorScore} pts</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>Debt-to-Income / FOIR (25 pts max)</span>
                    <span className="text-slate-200">{result.breakdown.debtObligationScore} pts</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>Employment & Stability (15 pts max)</span>
                    <span className="text-slate-200">{result.breakdown.employmentScore} pts</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>Age vs Loan Maturity (10 pts max)</span>
                    <span className="text-slate-200">{result.breakdown.ageTenureScore} pts</span>
                  </div>
                </div>
              </div>

              {/* Positive Factors */}
              {result.positiveFactors.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-800/80">
                  <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Positive Underwriting Factors</span>
                  </span>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {result.positiveFactors.map((fact, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-emerald-400 shrink-0">✓</span>
                        <span>{fact}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Areas to Improve */}
              {result.areasToImprove.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-800/80">
                  <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Areas to Improve</span>
                  </span>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {result.areasToImprove.map((area, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-amber-400 shrink-0">⚠</span>
                        <span>{area}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Improvement Suggestions */}
              {result.improvementSuggestions.length > 0 && (
                <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-900/40 space-y-1.5 text-xs">
                  <span className="font-semibold text-cyan-300">Actionable Suggestions:</span>
                  <ul className="space-y-1 text-slate-300">
                    {result.improvementSuggestions.map((sug, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-cyan-400 shrink-0">→</span>
                        <span>{sug}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Actions: Save Record & Consult AI */}
              <div className="space-y-2.5 pt-2">
                <button
                  onClick={handleSaveAssessment}
                  disabled={isSaving}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-xs flex items-center justify-center gap-2 border border-slate-700 transition-colors cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{isSaving ? 'Saving to Database...' : 'Save Assessment & Sync'}</span>
                </button>

                {saveSuccessMsg && (
                  <p className="text-xs text-emerald-400 text-center font-medium bg-emerald-950/40 p-2 rounded-lg border border-emerald-900/50">
                    {saveSuccessMsg}
                  </p>
                )}

                <button
                  onClick={onConsultAI}
                  className="w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-transform hover:scale-[1.01] cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Get AI Advice for this Profile</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
