import React, { useState } from 'react';
import { CurrencyCode, LoanInputs, AITipsResponse } from '../types/financial';
import { formatCurrency } from '../utils/calculations';
import {
  Sparkles,
  Send,
  Loader2,
  ShieldAlert,
  CheckCircle2,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  FileCheck,
  RefreshCw,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

interface AiFinancialTipsModuleProps {
  currency: CurrencyCode;
  sharedInputs: LoanInputs;
}

export const AiFinancialTipsModule: React.FC<AiFinancialTipsModuleProps> = ({
  currency,
  sharedInputs,
}) => {
  const [profile, setProfile] = useState<LoanInputs>(sharedInputs);
  const [userQuery, setUserQuery] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [aiResponse, setAiResponse] = useState<AITipsResponse | null>(null);
  const [provider, setProvider] = useState<string | null>(null);

  const sampleQuestions = [
    'How can I optimize my monthly budget to qualify for a larger loan?',
    'Should I prepay my existing personal loan before applying for a home loan?',
    'Which debt elimination strategy (Avalanche vs Snowball) works best for my profile?',
    'What specific steps will raise my credit score by 40+ points within 90 days?',
  ];

  const handleGenerateAdvice = async (customQuestion?: string) => {
    setLoading(true);
    setErrorMsg(null);

    const queryToSend = customQuestion || userQuery;

    try {
      const response = await fetch('/api/ai-tips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          monthlyIncome: profile.monthlyIncome,
          monthlyExpenses: profile.monthlyExpenses,
          existingEmi: profile.existingEmi,
          creditScore: profile.creditScore,
          loanAmount: profile.desiredLoanAmount,
          loanTenureYears: profile.loanTenureYears,
          employmentType: profile.employmentType,
          userQuery: queryToSend,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const resJson = await response.json();
      if (resJson.success && resJson.data) {
        setAiResponse(resJson.data);
        setProvider(resJson.provider);
      } else {
        throw new Error(resJson.error || 'Failed to parse AI response');
      }
    } catch (err: any) {
      console.error('Error generating AI advice:', err);
      setErrorMsg(err.message || 'Unable to generate financial recommendations at this time.');
    } finally {
      setLoading(false);
    }
  };

  const syncProfile = () => {
    setProfile(sharedInputs);
  };

  return (
    <div className="space-y-8">
      {/* Module Title */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-purple-400">
          <Sparkles className="w-4 h-4" />
          <span>Institutional Advisory Engine</span>
          <span className="text-slate-600">·</span>
          <span>Responsible & Non-Guaranteed Financial Guidance</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-100">AI-Powered Financial Guidance & Optimization</h1>
        <p className="text-sm text-slate-400 max-w-3xl">
          Get synthesized BFSI financial guidance tailored to your exact monthly income, current debt load, and credit
          standing. All requests are securely routed through our backend service.
        </p>
      </div>

      {/* Main Grid: Input Profile & Chat Prompt (Left) and Results (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* LEFT PANEL: Profile & Query Controls (5 Columns) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-purple-400" />
                <span>Financial Profile Context</span>
              </h2>
              <button
                onClick={syncProfile}
                title="Sync from other modules"
                className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Sync Inputs</span>
              </button>
            </div>

            {/* Profile Inputs Summary / Adjusters */}
            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Monthly Income:</span>
                <span className="font-mono font-semibold text-slate-100">
                  {formatCurrency(profile.monthlyIncome, currency)}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Monthly Living Expenses:</span>
                <span className="font-mono font-semibold text-slate-100">
                  {formatCurrency(profile.monthlyExpenses, currency)}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Existing Monthly EMIs:</span>
                <span className="font-mono font-semibold text-slate-100">
                  {formatCurrency(profile.existingEmi, currency)}
                </span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Credit Bureau Score:</span>
                <span className="font-mono font-bold text-cyan-400">{profile.creditScore}</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-slate-800/50">
                <span className="text-slate-400">Requested Loan:</span>
                <span className="font-mono font-semibold text-slate-100">
                  {formatCurrency(profile.desiredLoanAmount, currency)} ({profile.loanTenureYears} Yrs)
                </span>
              </div>
            </div>

            {/* Custom Question Input */}
            <div className="space-y-2 pt-2">
              <label className="block text-xs font-semibold text-slate-300">
                Specific Financial Inquiry (Optional)
              </label>
              <textarea
                rows={3}
                placeholder="Ask about debt reduction, EMI affordability, credit score boosts, or pre-application tips..."
                value={userQuery}
                onChange={(e) => setUserQuery(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg glass-input text-xs sm:text-sm text-slate-100 placeholder:text-slate-500"
              />
            </div>

            {/* Quick Sample Questions */}
            <div className="space-y-1.5">
              <span className="text-[11px] text-slate-400 font-medium">Suggested Topics:</span>
              <div className="flex flex-col gap-1.5">
                {sampleQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setUserQuery(q);
                      handleGenerateAdvice(q);
                    }}
                    className="text-left p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-[11px] text-slate-300 border border-slate-800 transition-colors cursor-pointer"
                  >
                    "{q}"
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              onClick={() => handleGenerateAdvice()}
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Synthesizing BFSI Advisory...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate AI Advisory</span>
                </>
              )}
            </button>

            {errorMsg && (
              <p className="text-xs text-rose-400 bg-rose-950/40 p-2.5 rounded-lg border border-rose-900/50">
                {errorMsg}
              </p>
            )}
          </div>
        </div>

        {/* RIGHT PANEL: AI Generated Insights (7 Columns) */}
        <div className="lg:col-span-7 space-y-6">
          {aiResponse ? (
            <div className="glass-panel p-6 sm:p-7 rounded-2xl border border-slate-800 space-y-6">
              {/* Header & Verdict */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 font-medium">Financial Readiness Verdict:</span>
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded border ${
                        aiResponse.affordabilityVerdict === 'Healthy'
                          ? 'text-emerald-400 bg-emerald-950/60 border-emerald-800'
                          : aiResponse.affordabilityVerdict === 'Stretched'
                          ? 'text-amber-400 bg-amber-950/60 border-amber-800'
                          : 'text-rose-400 bg-rose-950/60 border-rose-800'
                      }`}
                    >
                      {aiResponse.affordabilityVerdict}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-100">Executive Summary</h3>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-center font-mono">
                    <div className="text-[10px] text-slate-500 uppercase">Health Score</div>
                    <div className="text-base font-bold text-cyan-400">{aiResponse.healthScore} / 100</div>
                  </div>
                </div>
              </div>

              {/* Summary Narrative */}
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-900/50 p-4 rounded-xl border border-slate-800/80">
                {aiResponse.summary}
              </p>

              {/* Key Observations */}
              {aiResponse.keyObservations && aiResponse.keyObservations.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-cyan-400 flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Key Risk & Cashflow Observations</span>
                  </span>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {aiResponse.keyObservations.map((obs, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-cyan-400 shrink-0">·</span>
                        <span>{obs}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Recommendations */}
              <div className="space-y-3 pt-2 border-t border-slate-800/80">
                <span className="text-xs font-semibold text-slate-200">Personalized Actionable Recommendations</span>
                <div className="space-y-3">
                  {aiResponse.recommendations.map((rec, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800/80 space-y-1.5 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-100">{rec.action}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-400 font-mono">{rec.category}</span>
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                              rec.impact === 'High'
                                ? 'bg-rose-500/20 text-rose-300'
                                : rec.impact === 'Medium'
                                ? 'bg-amber-500/20 text-amber-300'
                                : 'bg-cyan-500/20 text-cyan-300'
                            }`}
                          >
                            {rec.impact} Impact
                          </span>
                        </div>
                      </div>
                      <p className="text-slate-300 leading-relaxed">{rec.detail}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pre-Application Checklist */}
              {aiResponse.preApplicationChecklist && aiResponse.preApplicationChecklist.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-800/80">
                  <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                    <FileCheck className="w-3.5 h-3.5" />
                    <span>Lender Pre-Application Checklist</span>
                  </span>
                  <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
                    {aiResponse.preApplicationChecklist.map((step, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{step}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Engine Provider & Disclaimer */}
              <div className="pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] text-slate-500">
                <div>
                  AI Engine:{' '}
                  <span className="font-mono text-slate-400 font-semibold">{provider || 'BFSI Advisory Engine'}</span>
                </div>
                <div className="text-[10px] text-slate-500 italic max-w-md">
                  {aiResponse.disclaimer ||
                    'Estimates for informational use only. Not formal bank sanction or official credit advice.'}
                </div>
              </div>
            </div>
          ) : (
            /* Empty State */
            <div className="glass-panel p-8 sm:p-12 rounded-2xl border border-slate-800 text-center space-y-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="space-y-1 max-w-sm mx-auto">
                <h3 className="text-base font-bold text-slate-200">No Advisory Generated Yet</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Review your financial numbers on the left and click "Generate AI Advisory" to receive custom BFSI
                  recommendations, debt mitigation strategies, and readiness checklists.
                </p>
              </div>
              <button
                onClick={() => handleGenerateAdvice()}
                disabled={loading}
                className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-colors cursor-pointer inline-flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Run Analysis Now</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
