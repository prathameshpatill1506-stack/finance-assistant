import React, { useState } from 'react';
import { X, BookOpen, Layers, CheckSquare, GitBranch, Shield, ArrowRight, Database } from 'lucide-react';

interface ArchitectureDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureDocsModal: React.FC<ArchitectureDocsModalProps> = ({ isOpen, onClose }) => {
  const [activeSection, setActiveSection] = useState<'architecture' | 'flow' | 'testing' | 'roadmap'>('architecture');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-4xl bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-100">
                FinPulse BFSI Platform Architecture & Documentation
              </h2>
              <p className="text-xs text-slate-400">System diagrams, data flows, testing matrix, and technical specifications</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-5 py-2.5 bg-slate-900/60 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveSection('architecture')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              activeSection === 'architecture' ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            System Architecture
          </button>
          <button
            onClick={() => setActiveSection('flow')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              activeSection === 'flow' ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Data Flow & Flowcharts
          </button>
          <button
            onClick={() => setActiveSection('testing')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              activeSection === 'testing' ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Testing & Verification Matrix
          </button>
          <button
            onClick={() => setActiveSection('roadmap')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              activeSection === 'roadmap' ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Future Roadmap
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-300 text-xs sm:text-sm">
          {activeSection === 'architecture' && (
            <div className="space-y-5">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>End-to-End System Architecture</span>
              </h3>
              <p className="text-slate-400 leading-relaxed text-xs">
                FinPulse follows a full-stack decoupled architecture. Financial logic and real-time calculators execute client-side with zero latency, while sensitive AI integrations (Gemini 3.8 Flash / Claude 3.5 Sonnet) and Google Sheets record synchronizations are securely handled via an Express serverless/API layer.
              </p>

              {/* ASCII / Monospace Architecture Diagram */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] sm:text-xs text-cyan-300 overflow-x-auto leading-relaxed">
{`                    +------------------------------------+
                    |             USER AGENT             |
                    |    React 19 SPA + Glassmorphism    |
                    +------------------------------------+
                                      |
                           [Client-Side Validation]
                                      |
         +----------------------------+----------------------------+
         |                            |                            |
+------------------+         +------------------+         +------------------+
|   LOAN ENGINE    |         | CREDIT ANALYZER  |         |  EMI CALCULATOR  |
| FOIR, DTI, Score |         | 5 Pillars & Risk |         | Exact Formula &  |
| Component Weight |         | Bureau Roadmap   |         | Amortization CSV |
+------------------+         +------------------+         +------------------+
         |                            |                            |
         +----------------------------+----------------------------+
                                      |
                    +------------------------------------+
                    |          BACKEND PROXY             |
                    |      Express.js API Layer          |
                    +------------------------------------+
                                 /          \\
                                /            \\
       +-------------------------------+      +-------------------------------+
       |       AI ADVISORY ENGINE      |      |   DATA STORAGE & INTEGRATION  |
       |  - Gemini 3.8 Flash (@genai)  |      |  - Local JSON Records Store   |
       |  - Anthropic Claude 3.5 Proxy |      |  - Google Sheets Webhook Sync |
       |  - High-Fidelity Rule Fallback|      |  - CSV/JSON Export Stream     |
       +-------------------------------+      +-------------------------------+`}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5 text-xs">
                  <span className="font-semibold text-slate-100 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Security & Credential Boundary</span>
                  </span>
                  <p className="text-slate-400 leading-relaxed">
                    Zero private API secrets or service account keys exist in browser bundles. AI prompts and Google Sheets webhook transfers pass through sanitized Express endpoints with rate limiting and input validation.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5 text-xs">
                  <span className="font-semibold text-slate-100 flex items-center gap-1.5">
                    <Database className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Data Governance & Minimization</span>
                  </span>
                  <p className="text-slate-400 leading-relaxed">
                    Financial records collect non-identifiable parameters (income brackets, DTI, eligibility score) and strictly prohibit banking passwords, account numbers, CVVs, or OTPs.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'flow' && (
            <div className="space-y-5">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-cyan-400" />
                <span>Workflow & Loan Eligibility Flowcharts</span>
              </h3>

              {/* Data Flow Diagram */}
              <div className="space-y-2">
                <span className="font-semibold text-xs text-slate-200">1. Data Flow Pipeline</span>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] sm:text-xs text-emerald-300 overflow-x-auto">
{`User Form Input ---> Client-Side Range Validation ---> Real-Time State Store
                                                              |
                  +-------------------------------------------+
                  |
                  v
[POST /api/records]   --->  Input Sanitization  --->  Write to records.json
                                                              |
                                                              +--> Forward to Google Sheet Webhook`}
                </div>
              </div>

              {/* Loan Eligibility Decision Flowchart */}
              <div className="space-y-2 pt-2">
                <span className="font-semibold text-xs text-slate-200">2. Loan Eligibility Underwriting Flowchart</span>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] sm:text-xs text-cyan-300 overflow-x-auto">
{`START
  |
  +--> Input: Monthly Income, Expenses, Existing EMI, Tenure, Credit Score, Age
  |
  +--> Validate: Required fields, positive values, age (18-75), score (300-900)
  |
  +--> Calculate DTI = (Existing EMI / Monthly Income) * 100
  |
  +--> Determine Allowable FOIR:
  |       - Income < 50k: 45-50%
  |       - Income 50k - 100k: 55%
  |       - Income > 100k: 60-65%
  |       - Co-Applicant: +5% Booster
  |
  +--> Max Allowable New EMI = (Monthly Income * FOIR) - Existing EMI
  |
  +--> Reverse-discount Max Eligible Loan: P = EMI * ((1+R)^N - 1) / (R * (1+R)^N)
  |
  +--> Multi-factor Score: Income(25) + Credit(25) + DTI(25) + Stability(15) + Age(10)
  |
  +--> Categorize Risk:
  |       - High: Score >= 75 & DTI <= 45% (Low Risk)
  |       - Moderate: Score >= 60 & DTI <= 55% (Moderate Risk)
  |       - Borderline: Score >= 45 (High Risk)
  |       - Ineligible: Score < 45 (Critical Underwriting Flag)
  |
  +--> Display Result & Improvement Suggestions
  |
END`}
                </div>
              </div>
            </div>
          )}

          {activeSection === 'testing' && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-emerald-400" />
                <span>Automated & Operational Testing Matrix</span>
              </h3>

              <div className="space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs">
                  <span className="font-semibold text-cyan-300">1. EMI Calculator Verifications</span>
                  <ul className="space-y-1 text-slate-400">
                    <li>✓ <strong>Standard Interest:</strong> P = ₹1,000,000, R = 10%, N = 5 Yrs =&gt; EMI = ₹21,247/mo verified.</li>
                    <li>✓ <strong>Zero Interest (0%):</strong> P = ₹600,000, R = 0%, N = 12 Mo =&gt; EMI = ₹50,000/mo without NaN errors.</li>
                    <li>✓ <strong>Boundary Tenures:</strong> Handled 1-month up to 35-year calculations with smooth amortization rendering.</li>
                    <li>✓ <strong>Prepayment Math:</strong> Extra principal properly decreases total interest and terminates loan tenure early.</li>
                  </ul>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs">
                  <span className="font-semibold text-emerald-300">2. Loan Eligibility Rule Engine</span>
                  <ul className="space-y-1 text-slate-400">
                    <li>✓ <strong>High Income / Prime Score:</strong> Score &gt; 80, Category High, Healthy DTI (&lt;30%).</li>
                    <li>✓ <strong>Overleveraged Profile:</strong> DTI &gt; 55% properly triggers Borderline/Ineligible status with clear advice.</li>
                    <li>✓ <strong>Retirement Horizon:</strong> Age + Tenure &gt; 65 properly identifies maturity strain.</li>
                    <li>✓ <strong>Co-Applicant Booster:</strong> Increases allowable FOIR by 5% and logs positive underwriting note.</li>
                  </ul>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs">
                  <span className="font-semibold text-purple-300">3. AI & Google Sheets Resilience</span>
                  <ul className="space-y-1 text-slate-400">
                    <li>✓ <strong>AI Backend Proxy:</strong> Connects to Gemini 3.8 Flash / Claude with graceful rule synthesizer fallback.</li>
                    <li>✓ <strong>Google Sheets Webhook:</strong> Asynchronous non-blocking post with immediate user feedback and CSV export.</li>
                    <li>✓ <strong>Security Validation:</strong> Reject negative incomes, non-numeric values, and sanitize applicant text strings.</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'roadmap' && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <ArrowRight className="w-4 h-4 text-cyan-400" />
                <span>Production Roadmap & Extensibility</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                  <span className="font-semibold text-slate-100">1. Machine Learning Underwriting</span>
                  <p className="text-slate-400">
                    Replace heuristic scoring with an XGBoost or Random Forest risk classifier trained on historical anonymized portfolio default data, complemented by SHAP explainability.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                  <span className="font-semibold text-slate-100">2. Client PDF Report Generator</span>
                  <p className="text-slate-400">
                    Enable 1-click download of branded multi-page BFSI assessment reports containing loan amortization charts, credit pillar diagnostics, and AI mitigation roadmaps.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                  <span className="font-semibold text-slate-100">3. Multi-Bureau Aggregation</span>
                  <p className="text-slate-400">
                    Direct integration with Account Aggregator (AA) and bureau APIs to automatically pull verified repayment tradelines with user consent.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                  <span className="font-semibold text-slate-100">4. Investment & Tax Optimizer</span>
                  <p className="text-slate-400">
                    Modules modeling Section 80C and 24(b) home loan tax deductions, SIP investments alongside loan servicing, and term insurance planning.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
